<?php

namespace Ttc\Intervention\Gif\Traits;

use Exception;
use Ttc\Intervention\Gif\Encoder\AbstractEncoder;
use Ttc\Intervention\Gif\Exception\EncoderException;

trait CanEncode
{
    /**
     * Encode current entity
     *
     * @return string
     */
    public function encode(): string
    {
        return $this->getEncoder()->encode();
    }

    /**
     * Get encoder object for current entity
     *
     * @return AbstractEncoder
     */
    protected function getEncoder(): \Ttc\Intervention\Gif\Encoder\AbstractEncoder
    {
        $classname = $this->getEncoderClassname();

        if (!class_exists($classname)) {
            throw new \Ttc\Intervention\Gif\Exception\EncoderException("Encoder for '" . get_class($this) . "' not found.");
        }

        return new $classname($this);
    }

    /**
     * Get encoder classname for current entity
     *
     * @return string
     */
    protected function getEncoderClassname(): string
    {
        return sprintf('Intervention\Gif\Encoder\%sEncoder', $this->getShortClassname());
    }
}
