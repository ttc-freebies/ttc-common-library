<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\DataSubBlock;
use Ttc\Intervention\Gif\ImageData;

class ImageDataDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode current source
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $data = new \Ttc\Intervention\Gif\ImageData();

        // LZW min. code size
        $char = $this->getNextByte();
        $size = (int) unpack('C', $char)[1];
        $data->setLzwMinCodeSize($size);

        do {
            // decode sub blocks
            $char = $this->getNextByte();
            $size = (int) unpack('C', $char)[1];
            if ($size > 0) {
                $data->addBlock(new \Ttc\Intervention\Gif\DataSubBlock($this->getNextBytes($size)));
            }
        } while ($char !== \Ttc\Intervention\Gif\AbstractEntity::TERMINATOR);

        return $data;
    }
}
