<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\ColorTable;
use Ttc\Intervention\Gif\LogicalScreen;
use Ttc\Intervention\Gif\LogicalScreenDescriptor;

class LogicalScreenDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode current source
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $screen = new \Ttc\Intervention\Gif\LogicalScreen();
        $screen->setDescriptor(\Ttc\Intervention\Gif\LogicalScreenDescriptor::decode($this->handle));
        if ($screen->getDescriptor()->hasGlobalColorTable()) {
            $screen->setColorTable(\Ttc\Intervention\Gif\ColorTable::decode($this->handle, function ($decoder) use ($screen) {
                $decoder->setLength($screen->getDescriptor()->getGlobalColorTableByteSize());
            }));
        }

        return $screen;
    }
}
