<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\Decoder\ApplicationExtensionDecoder;

class NetscapeApplicationExtensionDecoder extends \Ttc\Intervention\Gif\Decoder\ApplicationExtensionDecoder
{
    //
}
