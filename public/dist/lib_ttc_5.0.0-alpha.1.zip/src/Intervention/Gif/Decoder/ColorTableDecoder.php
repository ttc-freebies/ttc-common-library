<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\Color;
use Ttc\Intervention\Gif\ColorTable;
use Ttc\Intervention\Gif\Exception\DecoderException;

class ColorTableDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode given string to ColorTable
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $table = new \Ttc\Intervention\Gif\ColorTable();
        for ($i = 0; $i < ($this->getLength() / 3); $i++) {
            $table->addColor(\Ttc\Intervention\Gif\Color::decode($this->handle));
        }

        return $table;
    }
}
