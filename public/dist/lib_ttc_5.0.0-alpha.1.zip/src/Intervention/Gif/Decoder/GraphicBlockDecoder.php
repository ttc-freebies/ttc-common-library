<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\AbstractExtension;
use Ttc\Intervention\Gif\Exception\DecoderException;
use Ttc\Intervention\Gif\GraphicBlock;
use Ttc\Intervention\Gif\GraphicControlExtension;
use Ttc\Intervention\Gif\PlainTextExtension;
use Ttc\Intervention\Gif\TableBasedImage;

class GraphicBlockDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode current sourc
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $block = new \Ttc\Intervention\Gif\GraphicBlock();

        $marker = $this->getNextByte();
        $label = $this->getNextByte();
        $back = -2;

        // plain text extension
        if ($label === \Ttc\Intervention\Gif\PlainTextExtension::LABEL) {
            // graphic block is already complete
            return $block->setGraphicRenderingBlock(
                \Ttc\Intervention\Gif\PlainTextExtension::decode($this->handle, function ($decoder) use ($back) {
                    $decoder->movePointer($back);
                })
            );
        }

        if ($label === \Ttc\Intervention\Gif\GraphicControlExtension::LABEL) {
            // graphic control extension
            $block->setGraphicControlExtension(
                \Ttc\Intervention\Gif\GraphicControlExtension::decode($this->handle, function ($decoder) use ($back) {
                    $decoder->movePointer($back);
                })
            );

            $back = 0;
        }

        // table based image
        $block->setGraphicRenderingBlock(
            \Ttc\Intervention\Gif\TableBasedImage::decode($this->handle, function ($decoder) use ($back) {
                $decoder->movePointer($back);
            })
        );

        return $block;
    }
}
