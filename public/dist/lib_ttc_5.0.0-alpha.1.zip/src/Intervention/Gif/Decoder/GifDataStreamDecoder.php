<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\AbstractExtension;
use Ttc\Intervention\Gif\ApplicationExtension;
use Ttc\Intervention\Gif\ColorTable;
use Ttc\Intervention\Gif\CommentExtension;
use Ttc\Intervention\Gif\Contracts\DataBlock;
use Ttc\Intervention\Gif\Contracts\GraphicRenderingBlock;
use Ttc\Intervention\Gif\Contracts\SpecialPurposeBlock;
use Ttc\Intervention\Gif\Exception\DecoderException;
use Ttc\Intervention\Gif\GifDataStream;
use Ttc\Intervention\Gif\GraphicBlock;
use Ttc\Intervention\Gif\GraphicControlExtension;
use Ttc\Intervention\Gif\Header;
use Ttc\Intervention\Gif\ImageDescriptor;
use Ttc\Intervention\Gif\LogicalScreen;
use Ttc\Intervention\Gif\LogicalScreenDescriptor;
use Ttc\Intervention\Gif\PlainTextExtension;
use Ttc\Intervention\Gif\Trailer;

class GifDataStreamDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode current source to GifDataStream
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $gif = new \Ttc\Intervention\Gif\GifDataStream();

        $gif->setHeader(\Ttc\Intervention\Gif\Header::decode($this->handle));
        $gif->setLogicalScreen(\Ttc\Intervention\Gif\LogicalScreen::decode($this->handle));
        while (! feof($this->handle)) {
            if ($block = $this->decodeNextDataBlock()) {
                $gif->addData($block);
            }
        }

        return $gif;
    }

    /**
     * Decode data blocks from source into the given data stream object
     *
     * @return DataBlock
     */
    protected function decodeNextDataBlock(): ?\Ttc\Intervention\Gif\Contracts\DataBlock
    {
        //graphicblock ([GraphicControlExtension] | ((ImageDescriptor [LocalColorTable] ImageData) |  PlainTextExtension))
        //or special purpose block (ApplicationExtension | CommentExtension)

        $marker = $this->getNextByte();
        $label = $this->getNextByte();

        if ($marker === \Ttc\Intervention\Gif\AbstractExtension::MARKER) {
            // extension
            if ($label === \Ttc\Intervention\Gif\ApplicationExtension::LABEL) {
                // special purpose block
                return \Ttc\Intervention\Gif\ApplicationExtension::decode($this->handle, function ($decoder) {
                    $decoder->movePointer(-2);
                });
            } elseif ($label === \Ttc\Intervention\Gif\CommentExtension::LABEL) {
                // special purpose block
                return \Ttc\Intervention\Gif\CommentExtension::decode($this->handle, function ($decoder) {
                    $decoder->movePointer(-2);
                });
            }
        }

        if ($marker === \Ttc\Intervention\Gif\Trailer::MARKER) {
            return null;
        }

        return \Ttc\Intervention\Gif\GraphicBlock::decode($this->handle, function ($decoder) {
            $decoder->movePointer(-2);
        });
    }
}
