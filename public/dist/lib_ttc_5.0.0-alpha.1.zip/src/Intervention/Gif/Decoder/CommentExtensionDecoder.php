<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\CommentExtension;

class CommentExtensionDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode current source
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $this->getNextBytes(2); // skip marker & label

        $extension = new \Ttc\Intervention\Gif\CommentExtension();
        foreach ($this->decodeComments() as $comment) {
            $extension->addComment($comment);
        }

        return $extension;
    }

    /**
     * Decode comment from current source
     *
     * @return array
     */
    protected function decodeComments(): array
    {
        $comments = [];
        
        do {
            $byte = $this->getNextByte();
            $size = $this->decodeBlocksize($byte);
            if ($size > 0) {
                $comments[] = $this->getNextBytes($size);
            }
        } while ($byte !== \Ttc\Intervention\Gif\CommentExtension::TERMINATOR);

        return $comments;
    }

    /**
     * Decode blocksize of following comment
     *
     * @param  string $byte
     * @return int
     */
    protected function decodeBlocksize(string $byte): int
    {
        return (int) @unpack('C', $byte)[1];
    }
}
