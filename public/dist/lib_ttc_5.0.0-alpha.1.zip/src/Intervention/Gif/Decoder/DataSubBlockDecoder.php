<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\DataSubBlock;
use Ttc\Intervention\Gif\Exception\DecoderException;

class DataSubBlockDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode current sourc
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $char = $this->getNextByte();
        $size = (int) unpack('C', $char)[1];

        return new \Ttc\Intervention\Gif\DataSubBlock($this->getNextBytes($size));
    }
}
