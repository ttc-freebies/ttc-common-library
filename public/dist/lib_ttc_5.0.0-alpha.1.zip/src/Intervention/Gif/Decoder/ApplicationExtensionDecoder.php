<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\ApplicationExtension;
use Ttc\Intervention\Gif\DataSubBlock;
use Ttc\Intervention\Gif\NetscapeApplicationExtension;

class ApplicationExtensionDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode current source
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $result = new \Ttc\Intervention\Gif\ApplicationExtension();

        $marker = $this->getNextByte();
        $label = $this->getNextByte();
        $blocksize = $this->decodeBlockSize($this->getNextByte());
        $application = $this->getNextBytes($blocksize);

        if ($application === \Ttc\Intervention\Gif\NetscapeApplicationExtension::IDENTIFIER . \Ttc\Intervention\Gif\NetscapeApplicationExtension::AUTH_CODE) {
            $result = new \Ttc\Intervention\Gif\NetscapeApplicationExtension();

            // skip length
            $this->getNextByte();

            $result->setBlocks([new \Ttc\Intervention\Gif\DataSubBlock($this->getNextBytes(3))]);

            // skip terminator
            $this->getNextByte();

            return $result;
        }

        $result->setApplication($application);

        // decode data sub blocks
        $blocksize = $this->decodeBlockSize($this->getNextByte());
        while ($blocksize > 0) {
            $result->addBlock(new \Ttc\Intervention\Gif\DataSubBlock($this->getNextBytes($blocksize)));
            $blocksize = $this->decodeBlockSize($this->getNextByte());
        }

        return $result;
    }

    protected function decodeBlockSize(string $byte): int
    {
        return (int) @unpack('C', $byte)[1];
    }
}
