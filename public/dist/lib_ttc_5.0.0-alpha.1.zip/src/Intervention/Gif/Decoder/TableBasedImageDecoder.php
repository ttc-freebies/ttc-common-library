<?php

namespace Ttc\Intervention\Gif\Decoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\ColorTable;
use Ttc\Intervention\Gif\Exception\DecoderException;
use Ttc\Intervention\Gif\ImageData;
use Ttc\Intervention\Gif\ImageDescriptor;
use Ttc\Intervention\Gif\TableBasedImage;

class TableBasedImageDecoder extends \Ttc\Intervention\Gif\Decoder\AbstractDecoder
{
    /**
     * Decode current source
     *
     * @return AbstractEntity
     */
    public function decode(): \Ttc\Intervention\Gif\AbstractEntity
    {
        $image = new \Ttc\Intervention\Gif\TableBasedImage();

        // descriptor
        $image->setDescriptor(\Ttc\Intervention\Gif\ImageDescriptor::decode($this->handle));

        // local color table
        if ($image->getDescriptor()->hasLocalColorTable()) {
            $image->setColortable(\Ttc\Intervention\Gif\ColorTable::decode($this->handle, function ($decoder) use ($image) {
                $decoder->setLength($image->getDescriptor()->getLocalColorTableByteSize());
            }));
        }

        // image data
        $image->setData(\Ttc\Intervention\Gif\ImageData::decode($this->handle));

        return $image;
    }
}
