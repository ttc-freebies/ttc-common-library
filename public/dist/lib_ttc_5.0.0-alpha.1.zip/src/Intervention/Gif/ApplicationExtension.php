<?php

namespace Ttc\Intervention\Gif;

use Ttc\Intervention\Gif\Contracts\SpecialPurposeBlock;
use Ttc\Intervention\Gif\DataSubBlock;

class ApplicationExtension extends \Ttc\Intervention\Gif\AbstractExtension implements \Ttc\Intervention\Gif\Contracts\SpecialPurposeBlock
{
    public const LABEL = "\xFF";

    /**
     * Application Identifier & Auth Code
     *
     * @var string
     */
    protected $application = '';

    /**
     * Data Sub Blocks
     *
     * @var array
     */
    protected $blocks = [];

    public function getBlockSize(): int
    {
        return strlen($this->application);
    }

    public function setApplication(string $value): self
    {
        $this->application = $value;

        return $this;
    }

    public function getApplication(): string
    {
        return $this->application;
    }

    public function addBlock(\Ttc\Intervention\Gif\DataSubBlock $block): self
    {
        $this->blocks[] = $block;

        return $this;
    }

    public function setBlocks(array $blocks): self
    {
        $this->blocks = $blocks;

        return $this;
    }

    public function getBlocks(): array
    {
        return $this->blocks;
    }
}
