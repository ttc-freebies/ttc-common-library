<?php

namespace Ttc\Intervention\Gif;

use Ttc\Intervention\Gif\Contracts\DataBlock;
use Ttc\Intervention\Gif\Contracts\GraphicRenderingBlock;

class GraphicBlock extends \Ttc\Intervention\Gif\AbstractEntity implements \Ttc\Intervention\Gif\Contracts\DataBlock
{
    /**
     * Graphic control extension
     *
     * @var GraphicControlExtension
     */
    protected $graphicControlExtension;

    /**
     * Graphic rendering block
     *
     * @var GraphicRenderingBlock
     */
    protected $graphicRenderingBlock;

    /**
     * Create new instance
     */
    public function __construct()
    {
        $this->graphicRenderingBlock = new \Ttc\Intervention\Gif\TableBasedImage();
    }

    /**
     * Get graphic control extension
     *
     * @return GraphicControlExtension
     */
    public function getGraphicControlExtension(): ?\Ttc\Intervention\Gif\GraphicControlExtension
    {
        return $this->graphicControlExtension;
    }

    /**
     * Set graphic control extension
     *
     * @param GraphicControlExtension $extension
     */
    public function setGraphicControlExtension(\Ttc\Intervention\Gif\GraphicControlExtension $extension): self
    {
        $this->graphicControlExtension = $extension;

        return $this;
    }

    /**
     * Determine if current instance has graphic control extension
     *
     * @return boolean
     */
    public function hasGraphicControlExtension()
    {
        return is_a($this->graphicControlExtension, \Ttc\Intervention\Gif\GraphicControlExtension::class);
    }

    /**
     * Get graphic rendering block
     *
     * @return GraphicRenderingBlock
     */
    public function getGraphicRenderingBlock(): \Ttc\Intervention\Gif\Contracts\GraphicRenderingBlock
    {
        return $this->graphicRenderingBlock;
    }

    /**
     * Set graphic rendering block
     *
     * @param GraphicRenderingBlock $block
     */
    public function setGraphicRenderingBlock(\Ttc\Intervention\Gif\Contracts\GraphicRenderingBlock $block): self
    {
        $this->graphicRenderingBlock = $block;

        return $this;
    }
}
