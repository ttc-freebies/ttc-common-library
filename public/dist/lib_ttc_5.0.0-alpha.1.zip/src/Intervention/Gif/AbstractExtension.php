<?php

namespace Ttc\Intervention\Gif;

abstract class AbstractExtension extends \Ttc\Intervention\Gif\AbstractEntity
{
    public const MARKER = "\x21";
}
