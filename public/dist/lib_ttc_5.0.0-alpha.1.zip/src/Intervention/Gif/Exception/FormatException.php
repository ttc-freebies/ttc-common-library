<?php

namespace Ttc\Intervention\Gif\Exception;

class FormatException extends \RuntimeException
{
    # nothing to override
}
