<?php

namespace Ttc\Intervention\Gif\Exception;

class DecoderException extends \RuntimeException
{
    # nothing to override
}
