<?php

namespace Ttc\Intervention\Gif\Exception;

class NotReadableException extends \RuntimeException
{
    # nothing to override
}
