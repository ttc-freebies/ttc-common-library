<?php

namespace Ttc\Intervention\Gif\Exception;

class EncoderException extends \RuntimeException
{
    # nothing to override
}
