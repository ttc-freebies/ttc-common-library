<?php

namespace Ttc\Intervention\Gif;

class DisposalMethod
{
    public const UNDEFINED = 0;
    public const NONE = 1;
    public const BACKGROUND = 2;
    public const PREVIOUS = 3;
}
