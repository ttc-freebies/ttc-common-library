<?php

namespace Ttc\Intervention\Gif;

use Ttc\Intervention\Gif\Traits\CanHandleFiles;

class Decoder
{
    use \Ttc\Intervention\Gif\Traits\CanHandleFiles;

    /**
     * Decode given input
     *
     * @param  mixed $input
     * @return GifDataStream
     */
    public static function decode($input): \Ttc\Intervention\Gif\GifDataStream
    {
        switch (true) {
            case self::isFilePath($input):
                $handle = self::getHandleFromFilePath($input);
                break;

            default:
                $handle = self::getHandleFromData($input);
                break;
        }

        return \Ttc\Intervention\Gif\GifDataStream::decode($handle);
    }
}
