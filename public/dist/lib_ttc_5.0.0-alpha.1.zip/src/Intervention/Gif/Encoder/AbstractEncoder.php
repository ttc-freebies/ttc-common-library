<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\AbstractEntity;

abstract class AbstractEncoder
{
    /**
     * Source to encode
     *
     * @var AbstractEntity
     */
    protected $source;

    /**
     * Encode current source
     *
     * @return string
     */
    abstract public function encode(): string;

    /**
     * Create new instance
     *
     * @param AbstractEntity  $source
     */
    public function __construct(\Ttc\Intervention\Gif\AbstractEntity $source)
    {
        $this->source = $source;
    }
}
