<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\DataSubBlock;

class DataSubBlockEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param DataSubBlock $source
     */
    public function __construct(\Ttc\Intervention\Gif\DataSubBlock $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return pack('C', $this->source->getSize()) . $this->source->getValue();
    }
}
