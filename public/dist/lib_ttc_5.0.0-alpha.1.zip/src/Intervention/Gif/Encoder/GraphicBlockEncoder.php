<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\GraphicBlock as GraphicBlock;

class GraphicBlockEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param GraphicBlock $source
     */
    public function __construct(\Ttc\Intervention\Gif\GraphicBlock $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return implode('', [
            $this->encodeGraphicControlExtension(),
            $this->source->getGraphicRenderingBlock()->encode(),
        ]);
    }

    /**
     * Encode graphic control extension from current source
     *
     * @return string
     */
    protected function encodeGraphicControlExtension(): string
    {
        $extension = $this->source->getGraphicControlExtension();

        return $extension ? $extension->encode() : '';
    }
}
