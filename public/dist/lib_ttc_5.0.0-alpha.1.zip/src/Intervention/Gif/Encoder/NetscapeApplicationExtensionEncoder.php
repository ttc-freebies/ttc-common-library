<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\ApplicationExtension;
use Ttc\Intervention\Gif\NetscapeApplicationExtension;

class NetscapeApplicationExtensionEncoder extends \Ttc\Intervention\Gif\Encoder\ApplicationExtensionEncoder
{
    /**
     * Create new decoder instance
     *
     * @param ApplicationExtension $source
     */
    public function __construct(\Ttc\Intervention\Gif\NetscapeApplicationExtension $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return implode('', [
            \Ttc\Intervention\Gif\ApplicationExtension::MARKER,
            \Ttc\Intervention\Gif\ApplicationExtension::LABEL,
            pack('C', $this->source->getBlockSize()),
            $this->source->getApplication(),
            implode('', array_map(function ($block) {
                return $block->encode();
            }, $this->source->getBlocks())),
            \Ttc\Intervention\Gif\ApplicationExtension::TERMINATOR,
        ]);
    }
}
