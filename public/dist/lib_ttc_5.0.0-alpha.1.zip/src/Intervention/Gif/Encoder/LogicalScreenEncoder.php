<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\LogicalScreen;

class LogicalScreenEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param LogicalScreen $source
     */
    public function __construct(\Ttc\Intervention\Gif\LogicalScreen $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        $encoded = $this->source->getDescriptor()->encode();

        if ($this->source->hasColorTable()) {
            $encoded .= $this->source->getColorTable()->encode();
        }

        return $encoded;
    }
}
