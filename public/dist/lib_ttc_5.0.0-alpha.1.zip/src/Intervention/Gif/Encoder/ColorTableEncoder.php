<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\ColorTable;

class ColorTableEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param ColorTable $source
     */
    public function __construct(\Ttc\Intervention\Gif\ColorTable $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return implode('', array_map(function ($color) {
            return $color->encode();
        }, $this->source->getColors()));
    }
}
