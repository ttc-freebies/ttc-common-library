<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\AbstractEntity;
use Ttc\Intervention\Gif\Exception\EncoderException;
use Ttc\Intervention\Gif\ImageData;

class ImageDataEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param ImageData $source
     */
    public function __construct(\Ttc\Intervention\Gif\ImageData $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        if (! $this->source->hasBlocks()) {
            throw new \Ttc\Intervention\Gif\Exception\EncoderException("No data blocks in ImageData.");
        }

        return implode('', [
            pack('C', $this->source->getLzwMinCodeSize()),
            implode('', array_map(function ($block) {
                return $block->encode();
            }, $this->source->getBlocks())),
            \Ttc\Intervention\Gif\AbstractEntity::TERMINATOR,
        ]);
    }
}
