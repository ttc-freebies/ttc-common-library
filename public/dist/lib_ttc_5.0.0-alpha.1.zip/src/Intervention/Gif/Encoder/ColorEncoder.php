<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\Color;

class ColorEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param Color $source
     */
    public function __construct(\Ttc\Intervention\Gif\Color $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return implode('', [
            $this->encodeColorValue($this->source->getRed()),
            $this->encodeColorValue($this->source->getGreen()),
            $this->encodeColorValue($this->source->getBlue()),
        ]);
    }

    /**
     * Encode color value
     *
     * @return string
     */
    protected function encodeColorValue(int $value): string
    {
        return pack('C', $value);
    }
}
