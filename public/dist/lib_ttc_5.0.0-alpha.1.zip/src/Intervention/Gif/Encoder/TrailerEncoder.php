<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\Trailer as Trailer;

class TrailerEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param Trailer $source
     */
    public function __construct(\Ttc\Intervention\Gif\Trailer $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return \Ttc\Intervention\Gif\Trailer::MARKER;
    }
}
