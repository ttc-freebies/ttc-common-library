<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\PlainTextExtension as PlainTextExtension;

class PlainTextExtensionEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param PlainTextExtension $source
     */
    public function __construct(\Ttc\Intervention\Gif\PlainTextExtension $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        if (! $this->source->hasText()) {
            return '';
        }

        return implode('', [
            \Ttc\Intervention\Gif\PlainTextExtension::MARKER,
            \Ttc\Intervention\Gif\PlainTextExtension::LABEL,
            $this->encodeHead(),
            $this->encodeTexts(),
            \Ttc\Intervention\Gif\PlainTextExtension::TERMINATOR,
        ]);
    }

    /**
     * Encode head block
     *
     * @return string
     */
    protected function encodeHead(): string
    {
        return "\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    }

    /**
     * Encode text chunks
     *
     * @return string
     */
    protected function encodeTexts(): string
    {
        return implode('', array_map(function ($text) {
            return pack('C', strlen($text)) . $text;
        }, $this->source->getText()));
    }
}
