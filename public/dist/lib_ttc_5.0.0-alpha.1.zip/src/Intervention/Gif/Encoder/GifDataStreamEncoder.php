<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\GifDataStream;

class GifDataStreamEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param GifDataStream $source
     */
    public function __construct(\Ttc\Intervention\Gif\GifDataStream $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return implode('', [
            $this->source->getHeader()->encode(),
            $this->source->getLogicalScreen()->encode(),
            $this->encodeData(),
            $this->source->getTrailer()->encode(),
        ]);
    }

    /**
     * Encode data blocks of source
     *
     * @return string
     */
    protected function encodeData(): string
    {
        return implode('', array_map(function ($block) {
            return $block->encode();
        }, $this->source->getData()));
    }
}
