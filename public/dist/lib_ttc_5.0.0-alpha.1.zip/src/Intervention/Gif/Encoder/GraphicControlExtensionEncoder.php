<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\GraphicControlExtension;

class GraphicControlExtensionEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param GraphicControlExtension $source
     */
    public function __construct(\Ttc\Intervention\Gif\GraphicControlExtension $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return implode('', [
            \Ttc\Intervention\Gif\GraphicControlExtension::MARKER,
            \Ttc\Intervention\Gif\GraphicControlExtension::LABEL,
            \Ttc\Intervention\Gif\GraphicControlExtension::BLOCKSIZE,
            $this->encodePackedField(),
            $this->encodeDelay(),
            $this->encodeTransparentColorIndex(),
            \Ttc\Intervention\Gif\GraphicControlExtension::TERMINATOR,
        ]);
    }

    /**
     * Encode delay time
     *
     * @return string
     */
    protected function encodeDelay(): string
    {
        return pack('v*', $this->source->getDelay());
    }

    /**
     * Encode transparent color index
     *
     * @return string
     */
    protected function encodeTransparentColorIndex(): string
    {
        return pack('C', $this->source->getTransparentColorIndex());
    }

    /**
     * Encode packed field
     *
     * @return string
     */
    protected function encodePackedField(): string
    {
        return pack('C', bindec(implode('', [
            str_pad('0', 3, '0', STR_PAD_LEFT),
            str_pad(decbin($this->source->getDisposalMethod()), 3, '0', STR_PAD_LEFT),
            (int) $this->source->getUserInput(),
            (int) $this->source->getTransparentColorExistance(),
        ])));
    }
}
