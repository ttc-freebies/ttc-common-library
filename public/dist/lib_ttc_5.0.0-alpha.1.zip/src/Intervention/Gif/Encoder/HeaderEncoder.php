<?php

namespace Ttc\Intervention\Gif\Encoder;

use Ttc\Intervention\Gif\Header as Header;

class HeaderEncoder extends \Ttc\Intervention\Gif\Encoder\AbstractEncoder
{
    /**
     * Create new instance
     *
     * @param Header $source
     */
    public function __construct(\Ttc\Intervention\Gif\Header $source)
    {
        $this->source = $source;
    }

    /**
     * Encode current source
     *
     * @return string
     */
    public function encode(): string
    {
        return \Ttc\Intervention\Gif\Header::SIGNATURE . $this->source->getVersion();
    }
}
