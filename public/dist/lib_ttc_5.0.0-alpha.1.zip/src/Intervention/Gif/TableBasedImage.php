<?php

namespace Ttc\Intervention\Gif;

use Ttc\Intervention\Gif\Contracts\GraphicRenderingBlock;

class TableBasedImage extends \Ttc\Intervention\Gif\AbstractEntity implements \Ttc\Intervention\Gif\Contracts\GraphicRenderingBlock
{
    /**
     * Descriptor
     *
     * @var ImageDescriptor
     */
    protected $descriptor;

    /**
     * Local color table
     *
     * @var ColorTable
     */
    protected $colorTable;

    /**
     * Image data
     *
     * @var ImageData
     */
    protected $data;

    /**
     * Create new instance
     */
    public function __construct()
    {
        $this->descriptor = new \Ttc\Intervention\Gif\ImageDescriptor();
        $this->data = new \Ttc\Intervention\Gif\ImageData();
    }

    /**
     * Get descriptor
     *
     * @return ImageDescriptor
     */
    public function getDescriptor(): \Ttc\Intervention\Gif\ImageDescriptor
    {
        return $this->descriptor;
    }

    /**
     * Set descriptor
     *
     * @param ImageDescriptor $descriptor
     */
    public function setDescriptor(\Ttc\Intervention\Gif\ImageDescriptor $descriptor): self
    {
        $this->descriptor = $descriptor;

        return $this;
    }

    /**
     * Get color table
     *
     * @return ColorTable
     */
    public function getColorTable(): ?\Ttc\Intervention\Gif\ColorTable
    {
        return $this->colorTable;
    }

    /**
     * Set global color table
     *
     * @param ColorTable $table
     */
    public function setColorTable(\Ttc\Intervention\Gif\ColorTable $table): self
    {
        $this->colorTable = $table;

        return $this;
    }

    /**
     * Determine if current instance has color table
     *
     * @return boolean
     */
    public function hasColorTable()
    {
        return is_a($this->colorTable, \Ttc\Intervention\Gif\ColorTable::class);
    }

    /**
     * Get image data
     *
     * @return ImageData
     */
    public function getData(): \Ttc\Intervention\Gif\ImageData
    {
        return $this->data;
    }

    /**
     * Set image data
     *
     * @param ImageData $data
     */
    public function setData(\Ttc\Intervention\Gif\ImageData $data): self
    {
        $this->data = $data;

        return $this;
    }
}
