<?php

namespace Ttc\Intervention\Gif;

use Ttc\Intervention\Gif\Traits\CanDecode;
use Ttc\Intervention\Gif\Traits\CanEncode;
use ReflectionClass;

abstract class AbstractEntity
{
    use \Ttc\Intervention\Gif\Traits\CanEncode;
    use \Ttc\Intervention\Gif\Traits\CanDecode;

    public const TERMINATOR = "\x00";

    /**
     * Get short classname of current instance
     *
     * @return string
     */
    public static function getShortClassname(): string
    {
        return (new ReflectionClass(get_called_class()))->getShortName();
    }
}
