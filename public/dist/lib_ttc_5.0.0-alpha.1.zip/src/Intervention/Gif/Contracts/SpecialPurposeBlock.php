<?php

namespace Ttc\Intervention\Gif\Contracts;

interface SpecialPurposeBlock extends \Ttc\Intervention\Gif\Contracts\DataBlock
{
    # code...
}
