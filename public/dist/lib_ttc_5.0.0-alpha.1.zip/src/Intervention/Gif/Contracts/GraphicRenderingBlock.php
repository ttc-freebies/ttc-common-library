<?php

namespace Ttc\Intervention\Gif\Contracts;

interface GraphicRenderingBlock
{
    # code...
}
