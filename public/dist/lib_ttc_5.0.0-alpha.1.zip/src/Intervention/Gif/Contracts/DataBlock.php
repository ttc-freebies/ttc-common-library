<?php

namespace Ttc\Intervention\Gif\Contracts;

interface DataBlock
{
    # code...
}
