<?php

namespace Ttc\Intervention\Gif;

class Trailer extends \Ttc\Intervention\Gif\AbstractEntity
{
    public const MARKER = "\x3b";
}
