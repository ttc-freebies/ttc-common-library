<?php

namespace Ttc\Intervention\MimeSniffer\Types;

use Ttc\Intervention\MimeSniffer\AbstractType;

class ImageSvg extends \Ttc\Intervention\MimeSniffer\AbstractType
{
    /**
     * Name of content type
     *
     * @var string
     */
    public $name = "image/svg+xml";

    /**
     * Signature pattern
     *
     * @var string
     */
    protected $pattern = "/^(<\?xml[^>]*\?>.*)?<svg[^>]*>/is";
}
