<?php

namespace Ttc\Intervention\MimeSniffer\Types;

use Ttc\Intervention\MimeSniffer\AbstractBinaryType;

class AudioMpeg extends \Ttc\Intervention\MimeSniffer\AbstractBinaryType
{
    /**
     * Name of content type
     *
     * @var string
     */
    public $name = "audio/mpeg";

    /**
     * Signature pattern
     *
     * @var string
     */
    protected $pattern = "/^(FFFB|494433)/";
}
