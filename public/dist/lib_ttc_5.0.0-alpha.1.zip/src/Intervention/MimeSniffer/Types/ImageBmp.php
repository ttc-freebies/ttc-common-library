<?php

namespace Ttc\Intervention\MimeSniffer\Types;

use Ttc\Intervention\MimeSniffer\AbstractBinaryType;

class ImageBmp extends \Ttc\Intervention\MimeSniffer\AbstractBinaryType
{
    /**
     * Name of content type
     *
     * @var string
     */
    public $name = "image/bmp";

    /**
     * Signature pattern
     *
     * @var string
     */
    protected $pattern = "/^424D/";
}
