<?php

namespace Ttc\Intervention\MimeSniffer\Types;

use Ttc\Intervention\MimeSniffer\AbstractBinaryType;

class ImageHeif extends \Ttc\Intervention\MimeSniffer\AbstractBinaryType
{
    /**
     * Name of content type
     *
     * @var string
     */
    public $name = "image/heif";

    /**
     * Signature pattern
     *
     * ftyp(mif1|msf1)
     *
     * @var string
     */
    protected $pattern = "/66747970(6D696631|6D736631)/";
}
