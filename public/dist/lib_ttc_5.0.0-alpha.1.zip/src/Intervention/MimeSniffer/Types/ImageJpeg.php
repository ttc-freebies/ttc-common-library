<?php

namespace Ttc\Intervention\MimeSniffer\Types;

use Ttc\Intervention\MimeSniffer\AbstractBinaryType;

class ImageJpeg extends \Ttc\Intervention\MimeSniffer\AbstractBinaryType
{
    /**
     * Name of content type
     *
     * @var string
     */
    public $name = "image/jpeg";

    /**
     * Signature pattern
     *
     * @var string
     */
    protected $pattern = "/^FFD8FF(DB|E0|EE|E1)/";
}
