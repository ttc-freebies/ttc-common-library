<?php

namespace Ttc\Intervention\MimeSniffer\Types;

use Ttc\Intervention\MimeSniffer\AbstractBinaryType;

class VideoXmsvideo extends \Ttc\Intervention\MimeSniffer\AbstractBinaryType
{
    /**
     * Name of content type
     *
     * @var string
     */
    public $name = "video/x-msvideo";

    /**
     * Signature pattern
     *
     * @var string
     */
    protected $pattern = "/^52494646.{8}41564920/";
}
