<?php

namespace Ttc\Intervention\MimeSniffer\Types;

use Ttc\Intervention\MimeSniffer\AbstractBinaryType;

class ImagePsd extends \Ttc\Intervention\MimeSniffer\AbstractBinaryType
{
    /**
     * Name of content type
     *
     * @var string
     */
    public $name = "image/vnd.adobe.photoshop";

    /**
     * Signature pattern
     *
     * @var string
     */
    protected $pattern = "/^38425053/";
}
