<?php

namespace Ttc\Intervention\MimeSniffer\Types;

use Ttc\Intervention\MimeSniffer\AbstractBinaryType;

class ImageTiff extends \Ttc\Intervention\MimeSniffer\AbstractBinaryType
{
    /**
     * Name of content type
     *
     * @var string
     */
    public $name = "image/tiff";

    /**
     * Signature pattern
     *
     * @var string
     */
    protected $pattern = "/^(49492A00|4D4D002A)/";
}
