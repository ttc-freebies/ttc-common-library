<?php

namespace Ttc\Intervention\MimeSniffer\Exceptions;

use RuntimeException;

class NotMatchingException extends RuntimeException
{
    # nothing to override
}
