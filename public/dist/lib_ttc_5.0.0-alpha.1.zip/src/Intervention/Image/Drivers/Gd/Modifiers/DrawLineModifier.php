<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Modifiers;

use Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class DrawLineModifier extends \Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $image->eachFrame(function ($frame) {
            imageline(
                $frame->getCore(),
                $this->line()->getStart()->getX(),
                $this->line()->getStart()->getY(),
                $this->line()->getEnd()->getX(),
                $this->line()->getEnd()->getY(),
                $this->getBackgroundColor()->toInt()
            );
        });
    }
}
