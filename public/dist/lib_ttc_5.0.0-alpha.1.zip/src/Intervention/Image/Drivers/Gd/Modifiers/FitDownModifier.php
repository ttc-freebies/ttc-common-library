<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Modifiers;

use Ttc\Intervention\Image\Interfaces\SizeInterface;

class FitDownModifier extends \Ttc\Intervention\Image\Drivers\Gd\Modifiers\FitModifier
{
    protected function getResizeSize(\Ttc\Intervention\Image\Interfaces\SizeInterface $size): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return $size->scaleDown($this->width, $this->height);
    }
}
