<?php

namespace Ttc\Intervention\Image\Drivers\Gd;

use GdImage;
use Ttc\Intervention\Image\Collection;
use Ttc\Intervention\Image\Geometry\Rectangle;
use Ttc\Intervention\Image\Interfaces\FrameInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\SizeInterface;

class Frame implements \Ttc\Intervention\Image\Interfaces\FrameInterface
{
    public function __construct(
        protected GdImage $core,
        protected float $delay = 0,
        protected int $dispose = 1,
        protected int $offset_left = 0,
        protected int $offset_top = 0
    ) {
        //
    }

    public function setCore($core): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->core = $core;

        return $this;
    }

    public function getCore(): GdImage
    {
        return $this->core;
    }

    public function unsetCore(): void
    {
        unset($this->core);
    }

    public function getSize(): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return new \Ttc\Intervention\Image\Geometry\Rectangle(imagesx($this->core), imagesy($this->core));
    }

    public function getDelay(): float
    {
        return $this->delay;
    }

    public function setDelay(float $delay): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->delay = $delay;

        return $this;
    }

    public function getDispose(): int
    {
        return $this->dispose;
    }

    public function setDispose(int $dispose): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->dispose = $dispose;

        return $this;
    }

    public function setOffset(int $left, int $top): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->offset_left = $left;
        $this->offset_top = $top;

        return $this;
    }

    public function getOffsetLeft(): int
    {
        return $this->offset_left;
    }

    public function setOffsetLeft(int $offset): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->offset_left = $offset;

        return $this;
    }

    public function getOffsetTop(): int
    {
        return $this->offset_top;
    }

    public function setOffsetTop(int $offset): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->offset_top = $offset;

        return $this;
    }

    public function toImage(): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return new \Ttc\Intervention\Image\Drivers\Gd\Image(new \Ttc\Intervention\Image\Collection([$this]));
    }
}
