<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class GammaModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(protected float $gamma)
    {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            imagegammacorrect($frame->getCore(), 1, $this->gamma);
        }

        return $image;
    }
}
