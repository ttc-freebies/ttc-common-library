<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Encoders;

use Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder;
use Ttc\Intervention\Image\EncodedImage;
use Ttc\Intervention\Image\Interfaces\EncoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class PngEncoder extends \Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder implements \Ttc\Intervention\Image\Interfaces\EncoderInterface
{
    public function encode(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\EncodedImage
    {
        $data = $this->getBuffered(function () use ($image) {
            imagepng($image->getFrame()->getCore(), null, -1);
        });

        return new \Ttc\Intervention\Image\EncodedImage($data, 'image/png');
    }
}
