<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Decoders;

use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class RgbStringColorDecoder extends \Ttc\Intervention\Image\Drivers\Gd\Decoders\ArrayColorDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (!is_string($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        if (substr($input, 0, 3) !== 'rgb') {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        // rgb string like rgb(102, 200, 0)
        $pattern = "/^rgb ?\((?P<r>[0-9]{1,3}), ?(?P<g>[0-9]{1,3}), ?(?P<b>[0-9]{1,3})\)$/i";
        if ((bool) preg_match($pattern, $input, $matches)) {
            return parent::decode([$matches['r'], $matches['g'], $matches['b']]);
        }

        // rgba string like "rgba(200, 10, 30, 0.5)"
        $pattern = "/^rgba ?\(((?P<r>[0-9]{1,3})), ?((?P<g>[0-9]{1,3})), ?((?P<b>[0-9]{1,3})), ?(?P<a>[0-9.]{1,4})\)$/i";
        if ((bool) preg_match($pattern, $input, $matches)) {
            return parent::decode([$matches['r'], $matches['g'], $matches['b'], $matches['a']]);
        }

        throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
    }
}
