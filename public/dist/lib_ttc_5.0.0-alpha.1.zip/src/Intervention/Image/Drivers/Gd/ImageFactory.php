<?php

namespace Ttc\Intervention\Image\Drivers\Gd;

use Ttc\Intervention\Image\Collection;
use Ttc\Intervention\Image\Interfaces\FactoryInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class ImageFactory implements \Ttc\Intervention\Image\Interfaces\FactoryInterface
{
    public function newImage(int $width, int $height): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return new \Ttc\Intervention\Image\Drivers\Gd\Image(
            new \Ttc\Intervention\Image\Collection([
                new \Ttc\Intervention\Image\Drivers\Gd\Frame($this->newCore($width, $height))
            ])
        );
    }

    public function newCore(int $width, int $height)
    {
        $core = imagecreatetruecolor($width, $height);
        $color = imagecolorallocatealpha($core, 0, 0, 0, 127);
        imagefill($core, 0, 0, $color);
        imagesavealpha($core, true);

        return $core;
    }
}
