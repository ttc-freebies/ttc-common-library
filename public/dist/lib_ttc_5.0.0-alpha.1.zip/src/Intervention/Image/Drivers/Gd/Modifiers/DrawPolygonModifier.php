<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Modifiers;

use Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier;
use Ttc\Intervention\Image\Interfaces\DrawableInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class DrawPolygonModifier extends \Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(
        protected \Ttc\Intervention\Image\Interfaces\DrawableInterface $drawable
    ) {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $image->eachFrame(function ($frame) {
            if ($this->polygon()->hasBackgroundColor()) {
                imagefilledpolygon(
                    $frame->getCore(),
                    $this->polygon()->toArray(),
                    $this->polygon()->count(),
                    $this->getBackgroundColor()->toInt()
                );
            }

            if ($this->polygon()->hasBorder()) {
                imagesetthickness($frame->getCore(), $this->polygon()->getBorderSize());
                imagepolygon(
                    $frame->getCore(),
                    $this->polygon()->toArray(),
                    $this->polygon()->count(),
                    $this->getBorderColor()->toInt()
                );
            }
        });
    }
}
