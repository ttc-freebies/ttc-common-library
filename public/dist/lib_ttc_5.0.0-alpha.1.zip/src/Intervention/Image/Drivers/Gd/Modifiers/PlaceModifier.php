<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Modifiers;

use Ttc\Intervention\Image\Drivers\Gd\Image;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;
use Ttc\Intervention\Image\Interfaces\PointInterface;
use Ttc\Intervention\Image\Traits\CanResolveDriverClass;

class PlaceModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    use \Ttc\Intervention\Image\Traits\CanResolveDriverClass;

    /**
     * Create new modifier
     *
     */
    public function __construct(
        protected $element,
        protected string $position,
        protected int $offset_x,
        protected int $offset_y
    ) {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $watermark = $this->decodeWatermark();
        $position = $this->getPosition($image, $watermark);

        foreach ($image as $frame) {
            imagealphablending($frame->getCore(), true);
            imagecopy(
                $frame->getCore(),
                $watermark->getFrame()->getCore(),
                $position->getX(),
                $position->getY(),
                0,
                0,
                $watermark->getWidth(),
                $watermark->getHeight()
            );
        }

        return $image;
    }

    protected function decodeWatermark(): \Ttc\Intervention\Image\Drivers\Gd\Image
    {
        return $this->resolveDriverClass('InputHandler')->handle($this->element);
    }

    protected function getPosition(\Ttc\Intervention\Image\Interfaces\ImageInterface $image, \Ttc\Intervention\Image\Interfaces\ImageInterface $watermark): \Ttc\Intervention\Image\Interfaces\PointInterface
    {
        $image_size = $image->getSize()->movePivot($this->position, $this->offset_x, $this->offset_y);
        $watermark_size = $watermark->getSize()->movePivot($this->position);

        return $image_size->getRelativePositionTo($watermark_size);
    }
}
