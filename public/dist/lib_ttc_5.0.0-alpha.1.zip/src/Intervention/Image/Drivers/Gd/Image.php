<?php

namespace Ttc\Intervention\Image\Drivers\Gd;

use Ttc\Intervention\Image\Collection;
use Ttc\Intervention\Image\Drivers\Abstract\AbstractImage;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\FrameInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use IteratorAggregate;
use Traversable;

class Image extends \Ttc\Intervention\Image\Drivers\Abstract\AbstractImage implements \Ttc\Intervention\Image\Interfaces\ImageInterface, IteratorAggregate
{
    public function __construct(protected \Ttc\Intervention\Image\Collection $frames, protected int $loops = 0)
    {
        //
    }

    public function getIterator(): Traversable
    {
        return $this->frames;
    }

    public function count(): int
    {
        return $this->frames->count();
    }

    public function isAnimated(): bool
    {
        return $this->count() > 1;
    }

    public function getLoops(): int
    {
        return $this->loops;
    }

    public function setLoops(int $count): self
    {
        $this->loops = $count;

        return $this;
    }

    public function getFrame(int $key = 0): ?\Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        return $this->frames->get($key);
    }

    public function addFrame(\Ttc\Intervention\Image\Interfaces\FrameInterface $frame): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $this->frames->push($frame);

        return $this;
    }

    public function getWidth(): int
    {
        return imagesx($this->getFrame()->getCore());
    }

    public function getHeight(): int
    {
        return imagesy($this->getFrame()->getCore());
    }

    public function pickColor(int $x, int $y, int $frame_key = 0): ?\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if ($frame = $this->getFrame($frame_key)) {
            return new \Ttc\Intervention\Image\Drivers\Gd\Color(imagecolorat($frame->getCore(), $x, $y));
        }

        return null;
    }
}
