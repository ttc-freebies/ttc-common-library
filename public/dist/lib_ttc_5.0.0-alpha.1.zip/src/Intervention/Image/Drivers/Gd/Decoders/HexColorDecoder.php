<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Decoders;

use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class HexColorDecoder extends \Ttc\Intervention\Image\Drivers\Gd\Decoders\ArrayColorDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (!is_string($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        $pattern = '/^#?([a-f0-9]{1,2})([a-f0-9]{1,2})([a-f0-9]{1,2})$/i';
        $result = preg_match($pattern, $input, $matches);

        if ($result !== 1) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        return parent::decode([
            strlen($matches[1]) == '1' ? hexdec($matches[1] . $matches[1]) : hexdec($matches[1]),
            strlen($matches[2]) == '1' ? hexdec($matches[2] . $matches[2]) : hexdec($matches[2]),
            strlen($matches[3]) == '1' ? hexdec($matches[3] . $matches[3]) : hexdec($matches[3]),
        ]);
    }
}
