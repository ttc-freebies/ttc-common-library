<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Modifiers;

use Ttc\Intervention\Image\Interfaces\FrameInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class BlurModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(protected int $amount)
    {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            $this->blurFrame($frame);
        }

        return $image;
    }

    protected function blurFrame(\Ttc\Intervention\Image\Interfaces\FrameInterface $frame): void
    {
        for ($i = 0; $i < $this->amount; $i++) {
            imagefilter($frame->getCore(), IMG_FILTER_GAUSSIAN_BLUR);
        }
    }
}
