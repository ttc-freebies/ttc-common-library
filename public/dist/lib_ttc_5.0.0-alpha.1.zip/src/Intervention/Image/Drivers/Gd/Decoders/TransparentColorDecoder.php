<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Decoders;

use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class TransparentColorDecoder extends \Ttc\Intervention\Image\Drivers\Gd\Decoders\ArrayColorDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (! is_string($input) || strtolower($input) !== 'transparent') {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        return parent::decode([0, 0, 0, 0]);
    }
}
