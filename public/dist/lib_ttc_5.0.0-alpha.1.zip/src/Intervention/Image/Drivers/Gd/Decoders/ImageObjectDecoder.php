<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Decoders;

use Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;
use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class ImageObjectDecoder extends \Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (! is_a($input, \Ttc\Intervention\Image\Interfaces\ImageInterface::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        return $input;
    }
}
