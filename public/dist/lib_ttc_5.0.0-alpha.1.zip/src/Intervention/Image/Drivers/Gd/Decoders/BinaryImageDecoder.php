<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Decoders;

use Ttc\Intervention\Image\Collection;
use Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;
use Ttc\Intervention\Image\Drivers\Gd\Frame;
use Ttc\Intervention\Image\Drivers\Gd\Image;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\MimeSniffer\Types\ImageGif;
use Ttc\Intervention\Gif\Decoder as GifDecoder;
use Ttc\Intervention\Gif\Splitter as GifSplitter;
use Ttc\Intervention\Image\Exceptions\DecoderException;

class BinaryImageDecoder extends \Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (!is_string($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        if (! $this->inputType($input)->isBinary()) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        if (is_a($this->inputType($input), \Ttc\Intervention\MimeSniffer\Types\ImageGif::class)) {
            return $this->decodeGif($input); // decode (animated) gif
        }

        $gd = @imagecreatefromstring($input);

        if ($gd === false) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        if (! imageistruecolor($gd)) {
            imagepalettetotruecolor($gd);
        }

        imagesavealpha($gd, true);

        return new \Ttc\Intervention\Image\Drivers\Gd\Image(new \Ttc\Intervention\Image\Collection([new \Ttc\Intervention\Image\Drivers\Gd\Frame($gd)]));
    }

    protected function decodeGif($input): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $image = new \Ttc\Intervention\Image\Drivers\Gd\Image(new \Ttc\Intervention\Image\Collection());
        $gif = \Ttc\Intervention\Gif\Decoder::decode($input);


        if (!$gif->isAnimated()) {
            return $image->addFrame(new \Ttc\Intervention\Image\Drivers\Gd\Frame(@imagecreatefromstring($input)));
        }

        $image->setLoops($gif->getMainApplicationExtension()?->getLoops());

        $splitter = \Ttc\Intervention\Gif\Splitter::create($gif)->split();
        $delays = $splitter->getDelays();
        foreach ($splitter->coalesceToResources() as $key => $gd) {
            $image->addFrame((new \Ttc\Intervention\Image\Drivers\Gd\Frame($gd))->setDelay($delays[$key] / 100));
        }

        return $image;
    }
}
