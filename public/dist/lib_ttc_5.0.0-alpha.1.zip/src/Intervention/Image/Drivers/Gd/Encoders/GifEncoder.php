<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Encoders;

use Ttc\Intervention\Gif\Builder as GifBuilder;
use Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder;
use Ttc\Intervention\Image\EncodedImage;
use Ttc\Intervention\Image\Interfaces\EncoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class GifEncoder extends \Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder implements \Ttc\Intervention\Image\Interfaces\EncoderInterface
{
    public function encode(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\EncodedImage
    {
        if ($image->isAnimated()) {
            return $this->encodeAnimated($image);
        }

        $data = $this->getBuffered(function () use ($image) {
            imagegif($image->getFrame()->getCore());
        });

        return new \Ttc\Intervention\Image\EncodedImage($data, 'image/gif');
    }

    protected function encodeAnimated($image): \Ttc\Intervention\Image\EncodedImage
    {
        $builder = \Ttc\Intervention\Gif\Builder::canvas(
            $image->getWidth(),
            $image->getHeight(),
            $image->getLoops()
        );

        foreach ($image as $frame) {
            $source = $this->encode($frame->toImage());
            $builder->addFrame($source, $frame->getDelay());
        }

        return new \Ttc\Intervention\Image\EncodedImage($builder->encode(), 'image/gif');
    }
}
