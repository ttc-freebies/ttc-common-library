<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Modifiers;

use Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class DrawRectangleModifier extends \Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $image->eachFrame(function ($frame) {
            // draw background
            if ($this->rectangle()->hasBackgroundColor()) {
                imagefilledrectangle(
                    $frame->getCore(),
                    $this->position->getX(),
                    $this->position->getY(),
                    $this->position->getX() + $this->rectangle()->bottomRightPoint()->getX(),
                    $this->position->getY() + $this->rectangle()->bottomRightPoint()->getY(),
                    $this->getBackgroundColor()->toInt()
                );
            }

            if ($this->rectangle()->hasBorder()) {
                // draw border
                imagesetthickness($frame->getCore(), $this->rectangle()->getBorderSize());
                imagerectangle(
                    $frame->getCore(),
                    $this->position->getX(),
                    $this->position->getY(),
                    $this->position->getX() + $this->rectangle()->bottomRightPoint()->getX(),
                    $this->position->getY() + $this->rectangle()->bottomRightPoint()->getY(),
                    $this->getBorderColor()->toInt()
                );
            }
        });

        return $image;
    }
}
