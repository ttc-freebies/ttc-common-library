<?php

namespace Ttc\Intervention\Image\Drivers\Gd\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\SizeInterface;

class ScaleDownModifier extends \Ttc\Intervention\Image\Drivers\Gd\Modifiers\ResizeModifier
{
    protected function getAdjustedSize(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return $image->getSize()->scaleDown($this->width, $this->height);
    }
}
