<?php

namespace Ttc\Intervention\Image\Drivers\Gd;

use Ttc\Intervention\Image\Drivers\Abstract\AbstractInputHandler;
use Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;

class InputHandler extends \Ttc\Intervention\Image\Drivers\Abstract\AbstractInputHandler
{
    protected function chain(): \Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder
    {
        return new \Ttc\Intervention\Image\Drivers\Gd\Decoders\ImageObjectDecoder(
            new \Ttc\Intervention\Image\Drivers\Gd\Decoders\ArrayColorDecoder(
                new \Ttc\Intervention\Image\Drivers\Gd\Decoders\HtmlColorNameDecoder(
                    new \Ttc\Intervention\Image\Drivers\Gd\Decoders\RgbStringColorDecoder(
                        new \Ttc\Intervention\Image\Drivers\Gd\Decoders\HexColorDecoder(
                            new \Ttc\Intervention\Image\Drivers\Gd\Decoders\TransparentColorDecoder(
                                new \Ttc\Intervention\Image\Drivers\Gd\Decoders\FilePathImageDecoder(
                                    new \Ttc\Intervention\Image\Drivers\Gd\Decoders\BinaryImageDecoder(
                                        new \Ttc\Intervention\Image\Drivers\Gd\Decoders\DataUriImageDecoder(
                                            new \Ttc\Intervention\Image\Drivers\Gd\Decoders\Base64ImageDecoder()
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
        );
    }
}
