<?php

namespace Ttc\Intervention\Image\Drivers\Gd;

use Ttc\Intervention\Image\Drivers\Abstract\AbstractFont;
use Ttc\Intervention\Image\Geometry\Point;
use Ttc\Intervention\Image\Geometry\Polygon;
use Ttc\Intervention\Image\Geometry\Rectangle;

class Font extends \Ttc\Intervention\Image\Drivers\Abstract\AbstractFont
{
    public function getSize(): float
    {
        return floatval(ceil(parent::getSize() * 0.75));
    }

    /**
     * Calculate size of bounding box of given text
     *
     * @return Polygon
     */
    public function getBoxSize(string $text): \Ttc\Intervention\Image\Geometry\Polygon
    {
        if (!$this->hasFilename()) {
            // calculate box size from gd font
            $box = new \Ttc\Intervention\Image\Geometry\Rectangle(0, 0);
            $chars = mb_strlen($text);
            if ($chars > 0) {
                $box->setWidth($chars * $this->getGdFontWidth());
                $box->setHeight($this->getGdFontHeight());
            }
            return $box;
        }

        // calculate box size from font file with angle 0
        $box = imageftbbox(
            $this->getSize(),
            0,
            $this->getFilename(),
            $text
        );

        // build polygon from points
        $polygon = new \Ttc\Intervention\Image\Geometry\Polygon();
        $polygon->addPoint(new \Ttc\Intervention\Image\Geometry\Point($box[6], $box[7]));
        $polygon->addPoint(new \Ttc\Intervention\Image\Geometry\Point($box[4], $box[5]));
        $polygon->addPoint(new \Ttc\Intervention\Image\Geometry\Point($box[2], $box[3]));
        $polygon->addPoint(new \Ttc\Intervention\Image\Geometry\Point($box[0], $box[1]));

        return $polygon;
    }

    public function getGdFont(): int
    {
        if (is_numeric($this->filename)) {
            return $this->filename;
        }

        return 1;
    }

    protected function getGdFontWidth(): int
    {
        return $this->getGdFont() + 4;
    }

    protected function getGdFontHeight(): int
    {
        switch ($this->getGdFont()) {
            case 2:
                return 14;

            case 3:
                return 14;

            case 4:
                return 16;

            case 5:
                return 16;

            default:
            case 1:
                return 8;
        }
    }
}
