<?php

namespace Ttc\Intervention\Image\Drivers\Abstract\Modifiers;

use Ttc\Intervention\Image\Geometry\Rectangle;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\SizeInterface;

abstract class AbstractFitModifier
{
    public function __construct(
        protected int $width,
        protected int $height,
        protected string $position = 'center'
    ) {
        //
    }

    protected function getCropSize(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        $imagesize = $image->getSize();

        $crop = new \Ttc\Intervention\Image\Geometry\Rectangle($this->width, $this->height);
        $crop = $crop->contain(
            $imagesize->getWidth(),
            $imagesize->getHeight()
        )->alignPivotTo($imagesize, $this->position);

        return $crop;
    }

    protected function getResizeSize(\Ttc\Intervention\Image\Interfaces\SizeInterface $size): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return $size->scale($this->width, $this->height);
    }
}
