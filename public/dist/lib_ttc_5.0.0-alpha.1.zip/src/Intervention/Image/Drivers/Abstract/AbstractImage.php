<?php

namespace Ttc\Intervention\Image\Drivers\Abstract;

use Ttc\Intervention\Image\Collection;
use Ttc\Intervention\Image\EncodedImage;
use Ttc\Intervention\Image\Geometry\Circle;
use Ttc\Intervention\Image\Geometry\Ellipse;
use Ttc\Intervention\Image\Geometry\Line;
use Ttc\Intervention\Image\Geometry\Point;
use Ttc\Intervention\Image\Geometry\Polygon;
use Ttc\Intervention\Image\Geometry\Rectangle;
use Ttc\Intervention\Image\Interfaces\CollectionInterface;
use Ttc\Intervention\Image\Interfaces\EncoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;
use Ttc\Intervention\Image\Interfaces\SizeInterface;
use Ttc\Intervention\Image\Traits\CanHandleInput;
use Ttc\Intervention\Image\Traits\CanResolveDriverClass;
use Ttc\Intervention\Image\Traits\CanRunCallback;

abstract class AbstractImage implements \Ttc\Intervention\Image\Interfaces\ImageInterface
{
    use \Ttc\Intervention\Image\Traits\CanResolveDriverClass;
    use \Ttc\Intervention\Image\Traits\CanHandleInput;
    use \Ttc\Intervention\Image\Traits\CanRunCallback;

    public function eachFrame(callable $callback): self
    {
        foreach ($this as $frame) {
            $callback($frame);
        }

        return $this;
    }

    public function getSize(): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return new \Ttc\Intervention\Image\Geometry\Rectangle($this->getWidth(), $this->getHeight());
    }

    public function size(): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return $this->getSize();
    }

    public function modify(\Ttc\Intervention\Image\Interfaces\ModifierInterface $modifier): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $modifier->apply($this);
    }

    public function encode(\Ttc\Intervention\Image\Interfaces\EncoderInterface $encoder): \Ttc\Intervention\Image\EncodedImage
    {
        return $encoder->encode($this);
    }

    public function toJpeg(int $quality = 75): \Ttc\Intervention\Image\EncodedImage
    {
        return $this->encode(
            $this->resolveDriverClass('Encoders\JpegEncoder', $quality)
        );
    }

    public function toWebp(int $quality = 75): \Ttc\Intervention\Image\EncodedImage
    {
        return $this->encode(
            $this->resolveDriverClass('Encoders\WebpEncoder', $quality)
        );
    }

    public function toGif(): \Ttc\Intervention\Image\EncodedImage
    {
        return $this->encode(
            $this->resolveDriverClass('Encoders\GifEncoder')
        );
    }

    public function toPng(): \Ttc\Intervention\Image\EncodedImage
    {
        return $this->encode(
            $this->resolveDriverClass('Encoders\PngEncoder')
        );
    }

    public function greyscale(): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\GreyscaleModifier')
        );
    }

    public function invert(): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\InvertModifier')
        );
    }

    public function brightness(int $level): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\BrightnessModifier', $level)
        );
    }

    public function contrast(int $level): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\ContrastModifier', $level)
        );
    }

    public function gamma(float $gamma): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\GammaModifier', $gamma)
        );
    }

    public function blur(int $amount = 5): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\BlurModifier', $amount)
        );
    }

    public function rotate(float $angle, $background = 'ffffff'): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\RotateModifier', $angle, $background)
        );
    }

    /**
     * Creates a vertical mirror image
     *
     * @return ImageInterface
     */
    public function flip(): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\FlipModifier')
        );
    }

    /**
     * Creates a horizontal mirror image
     *
     * @return ImageInterface
     */
    public function flop(): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\FlopModifier')
        );
    }

    public function place($element, string $position = 'top-left', int $offset_x = 0, int $offset_y = 0): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass(
                'Modifiers\PlaceModifier',
                $element,
                $position,
                $offset_x,
                $offset_y
            )
        );
    }

    public function fill($color, ?int $x = null, ?int $y = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $color = $this->handleInput($color);
        $position = (is_null($x) && is_null($y)) ? null : new \Ttc\Intervention\Image\Geometry\Point($x, $y);

        return $this->modify(
            $this->resolveDriverClass(
                'Modifiers\FillModifier',
                $color,
                $position
            )
        );
    }

    public function pixelate(int $size): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\PixelateModifier', $size)
        );
    }

    public function sharpen(int $amount = 10): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\SharpenModifier', $amount)
        );
    }

    public function pickColors(int $x, int $y): \Ttc\Intervention\Image\Interfaces\CollectionInterface
    {
        $colors = new \Ttc\Intervention\Image\Collection();
        foreach ($this as $key => $frame) {
            $colors->push($this->pickColor($x, $y, $key));
        }

        return $colors;
    }

    public function text(string $text, int $x, int $y, ?callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $font = $this->runCallback($init, $this->resolveDriverClass('Font'));

        $modifier = $this->resolveDriverClass('Modifiers\TextWriter', new \Ttc\Intervention\Image\Geometry\Point($x, $y), $font, $text);

        return $this->modify($modifier);
    }

    public function drawPixel(int $x, int $y, $color = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\DrawPixelModifier', new \Ttc\Intervention\Image\Geometry\Point($x, $y), $color)
        );
    }

    public function drawRectangle(int $x, int $y, ?callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $rectangle = $this->runCallback($init, new \Ttc\Intervention\Image\Geometry\Rectangle(0, 0));
        $modifier = $this->resolveDriverClass('Modifiers\DrawRectangleModifier', new \Ttc\Intervention\Image\Geometry\Point($x, $y), $rectangle);

        return $this->modify($modifier);
    }

    public function drawEllipse(int $x, int $y, ?callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $ellipse = $this->runCallback($init, new \Ttc\Intervention\Image\Geometry\Ellipse(0, 0));
        $modifier = $this->resolveDriverClass('Modifiers\DrawEllipseModifier', new \Ttc\Intervention\Image\Geometry\Point($x, $y), $ellipse);

        return $this->modify($modifier);
    }

    public function drawCircle(int $x, int $y, ?callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $circle = $this->runCallback($init, new \Ttc\Intervention\Image\Geometry\Circle(0));
        $modifier = $this->resolveDriverClass('Modifiers\DrawEllipseModifier', new \Ttc\Intervention\Image\Geometry\Point($x, $y), $circle);

        return $this->modify($modifier);
    }

    public function drawLine(callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $line = $this->runCallback($init, new \Ttc\Intervention\Image\Geometry\Line(new \Ttc\Intervention\Image\Geometry\Point(), new \Ttc\Intervention\Image\Geometry\Point()));
        $modifier = $this->resolveDriverClass('Modifiers\DrawLineModifier', $line->getStart(), $line);

        return $this->modify($modifier);
    }

    public function drawPolygon(callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $polygon = $this->runCallback($init, new \Ttc\Intervention\Image\Geometry\Polygon());
        $modifier = $this->resolveDriverClass('Modifiers\DrawPolygonModifier', $polygon);

        return $this->modify($modifier);
    }

    public function resize(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\ResizeModifier', $width, $height)
        );
    }

    public function resizeDown(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\ResizeDownModifier', $width, $height)
        );
    }

    public function scale(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\ScaleModifier', $width, $height)
        );
    }

    public function scaleDown(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\ScaleDownModifier', $width, $height)
        );
    }

    public function fit(int $width, int $height, string $position = 'center'): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\FitModifier', $width, $height, $position)
        );
    }

    public function fitDown(int $width, int $height, string $position = 'center'): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\FitDownModifier', $width, $height, $position)
        );
    }

    public function pad(int $width, int $height, $background = 'ffffff', string $position = 'center'): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\PadModifier', $width, $height, $background, $position)
        );
    }

    public function padDown(
        int $width,
        int $height,
        $background = 'ffffff',
        string $position = 'center'
    ): \Ttc\Intervention\Image\Interfaces\ImageInterface {
        return $this->modify(
            $this->resolveDriverClass('Modifiers\PadDownModifier', $width, $height, $background, $position)
        );
    }

    public function destroy(): void
    {
        $this->modify(
            $this->resolveDriverClass('Modifiers\DestroyModifier')
        );
    }
}
