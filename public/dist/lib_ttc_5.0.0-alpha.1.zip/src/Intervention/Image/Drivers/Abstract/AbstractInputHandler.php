<?php

namespace Ttc\Intervention\Image\Drivers\Abstract;

use Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

abstract class AbstractInputHandler
{
    abstract protected function chain(): \Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;

    public function handle($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        return $this->chain()->handle($input);
    }
}
