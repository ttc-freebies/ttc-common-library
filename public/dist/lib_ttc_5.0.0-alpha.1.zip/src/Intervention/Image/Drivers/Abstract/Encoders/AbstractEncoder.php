<?php

namespace Ttc\Intervention\Image\Drivers\Abstract\Encoders;

use Ttc\Intervention\Image\Interfaces\EncoderInterface;

abstract class AbstractEncoder implements \Ttc\Intervention\Image\Interfaces\EncoderInterface
{
    protected $quality;

    /**
     * Get return value of callback through output buffer
     *
     * @param  callable $callback
     * @return string
     */
    protected function getBuffered(callable $callback): string
    {
        ob_start();
        $callback();
        $buffer = ob_get_contents();
        ob_end_clean();

        return $buffer;
    }

    public function setQuality(int $quality): \Ttc\Intervention\Image\Interfaces\EncoderInterface
    {
        $this->quality = $quality;

        return $this;
    }

    public function getQuality(): int
    {
        return $this->quality;
    }
}
