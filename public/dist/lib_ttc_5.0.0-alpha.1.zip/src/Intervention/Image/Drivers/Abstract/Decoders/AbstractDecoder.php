<?php

namespace Ttc\Intervention\Image\Drivers\Abstract\Decoders;

use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\MimeSniffer\MimeSniffer;
use Ttc\Intervention\MimeSniffer\AbstractType;

abstract class AbstractDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function __construct(protected ?\Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder $successor = null)
    {
        //
    }

    final public function handle($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        try {
            $decoded = $this->decode($input);
        } catch (\Ttc\Intervention\Image\Exceptions\DecoderException $e) {
            if (!$this->hasSuccessor()) {
                throw new \Ttc\Intervention\Image\Exceptions\DecoderException($e->getMessage());
            }

            return $this->successor->handle($input);
        }

        return $decoded;
    }

    protected function hasSuccessor(): bool
    {
        return $this->successor !== null;
    }

    protected function inputType($input): \Ttc\Intervention\MimeSniffer\AbstractType
    {
        return \Ttc\Intervention\MimeSniffer\MimeSniffer::createFromString($input)->getType();
    }
}
