<?php

namespace Ttc\Intervention\Image\Drivers\Abstract\Modifiers;

use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Exceptions\GeometryException;
use Ttc\Intervention\Image\Geometry\Ellipse;
use Ttc\Intervention\Image\Geometry\Line;
use Ttc\Intervention\Image\Geometry\Polygon;
use Ttc\Intervention\Image\Geometry\Rectangle;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DrawableInterface;
use Ttc\Intervention\Image\Interfaces\PointInterface;
use Ttc\Intervention\Image\Traits\CanHandleInput;

class AbstractDrawModifier
{
    use \Ttc\Intervention\Image\Traits\CanHandleInput;

    public function __construct(
        protected \Ttc\Intervention\Image\Interfaces\PointInterface $position,
        protected \Ttc\Intervention\Image\Interfaces\DrawableInterface $drawable
    ) {
        //
    }

    public function drawable(): \Ttc\Intervention\Image\Interfaces\DrawableInterface
    {
        return $this->drawable;
    }

    protected function getBackgroundColor(): ?\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        try {
            $color = $this->handleInput($this->drawable->getBackgroundColor());
        } catch (\Ttc\Intervention\Image\Exceptions\DecoderException $e) {
            return $this->handleInput('transparent');
        }

        return $color;
    }

    protected function getBorderColor(): ?\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        try {
            $color = $this->handleInput($this->drawable->getBorderColor());
        } catch (\Ttc\Intervention\Image\Exceptions\DecoderException $e) {
            return $this->handleInput('transparent');
        }

        return $color;
    }

    public function polygon(): \Ttc\Intervention\Image\Geometry\Polygon
    {
        if (!is_a($this->drawable(), \Ttc\Intervention\Image\Geometry\Polygon::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\GeometryException(
                'Shape mismatch. Excepted Polygon::class, found ' . get_class($this->drawable())
            );
        }

        return $this->drawable();
    }

    public function ellipse(): \Ttc\Intervention\Image\Geometry\Ellipse
    {
        if (!is_a($this->drawable(), \Ttc\Intervention\Image\Geometry\Ellipse::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\GeometryException(
                'Shape mismatch. Excepted Ellipse::class, found ' . get_class($this->drawable())
            );
        }

        return $this->drawable();
    }

    public function line(): \Ttc\Intervention\Image\Geometry\Line
    {
        if (!is_a($this->drawable(), \Ttc\Intervention\Image\Geometry\Line::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\GeometryException(
                'Shape mismatch. Excepted Line::class, found ' . get_class($this->drawable())
            );
        }

        return $this->drawable();
    }

    public function rectangle(): \Ttc\Intervention\Image\Geometry\Rectangle
    {
        if (!is_a($this->drawable(), \Ttc\Intervention\Image\Geometry\Rectangle::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\GeometryException(
                'Shape mismatch. Excepted Rectangle::class, found ' . get_class($this->drawable())
            );
        }

        return $this->drawable();
    }
}
