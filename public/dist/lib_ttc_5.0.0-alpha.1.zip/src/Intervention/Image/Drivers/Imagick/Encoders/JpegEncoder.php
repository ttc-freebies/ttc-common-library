<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Encoders;

use Imagick;
use Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder;
use Ttc\Intervention\Image\EncodedImage;
use Ttc\Intervention\Image\Interfaces\EncoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class JpegEncoder extends \Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder implements \Ttc\Intervention\Image\Interfaces\EncoderInterface
{
    public function __construct(int $quality)
    {
        $this->quality = $quality;
    }

    public function encode(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\EncodedImage
    {
        $format = 'jpeg';
        $compression = Imagick::COMPRESSION_JPEG;

        $imagick = $image->getFrame()->getCore();
        $imagick->setImageBackgroundColor('white');
        $imagick->setBackgroundColor('white');
        $imagick->setFormat($format);
        $imagick->setImageFormat($format);
        $imagick->setCompression($compression);
        $imagick->setImageCompression($compression);
        $imagick->setCompressionQuality($this->quality);
        $imagick->setImageCompressionQuality($this->quality);

        return new \Ttc\Intervention\Image\EncodedImage($imagick->getImagesBlob(), 'image/jpeg');
    }
}
