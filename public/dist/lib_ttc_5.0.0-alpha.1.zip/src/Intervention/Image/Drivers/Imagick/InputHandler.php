<?php

namespace Ttc\Intervention\Image\Drivers\Imagick;

use Ttc\Intervention\Image\Drivers\Abstract\AbstractInputHandler;
use Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;

class InputHandler extends \Ttc\Intervention\Image\Drivers\Abstract\AbstractInputHandler
{
    protected function chain(): \Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder
    {
        return new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\ImageObjectDecoder(
            new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\ArrayColorDecoder(
                new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\HexColorDecoder(
                    new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\HtmlColorNameDecoder(
                        new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\RgbStringColorDecoder(
                            new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\TransparentColorDecoder(
                                new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\FilePathImageDecoder(
                                    new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\BinaryImageDecoder(
                                        new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\DataUriImageDecoder(
                                            new \Ttc\Intervention\Image\Drivers\Imagick\Decoders\Base64ImageDecoder()
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
        );
    }
}
