<?php

namespace Ttc\Intervention\Image\Drivers\Imagick;

use Imagick;
use Ttc\Intervention\Image\Geometry\Rectangle;
use Ttc\Intervention\Image\Interfaces\FrameInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\SizeInterface;

class Frame implements \Ttc\Intervention\Image\Interfaces\FrameInterface
{
    public function __construct(protected Imagick $core)
    {
        //
    }

    public function setCore($core): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->core = $core;

        return $this;
    }

    public function getCore(): Imagick
    {
        return $this->core;
    }

    public function getSize(): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return new \Ttc\Intervention\Image\Geometry\Rectangle(
            $this->core->getImageWidth(),
            $this->core->getImageHeight()
        );
    }

    public function getDelay(): float
    {
        return $this->core->getImageDelay() / 100;
    }

    public function setDelay(float $delay): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->core->setImageDelay(intval(round($delay * 100)));

        return $this;
    }

    public function getDispose(): int
    {
        return $this->core->getImageDispose();
    }

    public function setDispose(int $dispose): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->core->setImageDispose($dispose);

        return $this;
    }

    public function setOffset(int $left, int $top): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        $this->core->setImagePage(
            $this->core->getImageWidth(),
            $this->core->getImageHeight(),
            $left,
            $top
        );

        return $this;
    }

    public function getOffsetLeft(): int
    {
        return $this->core->getImagePage()['x'];
    }

    public function setOffsetLeft(int $offset): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        return $this->setOffset($offset, $this->getOffsetTop());
    }

    public function getOffsetTop(): int
    {
        return $this->core->getImagePage()['y'];
    }

    public function setOffsetTop(int $offset): \Ttc\Intervention\Image\Interfaces\FrameInterface
    {
        return $this->setOffset($this->getOffsetLeft(), $offset);
    }

    public function toImage(): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return new \Ttc\Intervention\Image\Drivers\Imagick\Image($this->getCore());
    }
}
