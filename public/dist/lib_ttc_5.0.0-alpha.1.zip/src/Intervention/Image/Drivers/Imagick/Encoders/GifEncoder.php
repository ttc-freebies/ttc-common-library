<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Encoders;

use Imagick;
use Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder;
use Ttc\Intervention\Image\Drivers\Imagick\Image;
use Ttc\Intervention\Image\EncodedImage;
use Ttc\Intervention\Image\Exceptions\EncoderException;
use Ttc\Intervention\Image\Interfaces\EncoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class GifEncoder extends \Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder implements \Ttc\Intervention\Image\Interfaces\EncoderInterface
{
    public function encode(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\EncodedImage
    {
        $format = 'gif';
        $compression = Imagick::COMPRESSION_LZW;

        if (!is_a($image, \Ttc\Intervention\Image\Drivers\Imagick\Image::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\EncoderException('Image does not match the current driver.');
        }

        $imagick = $image->getImagick();
        $imagick->setFormat($format);
        $imagick->setImageFormat($format);
        $imagick->setCompression($compression);
        $imagick->setImageCompression($compression);
        $imagick = $imagick->deconstructImages();

        return new \Ttc\Intervention\Image\EncodedImage($imagick->getImagesBlob(), 'image/gif');
    }
}
