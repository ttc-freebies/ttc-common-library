<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Imagick;
use ImagickDraw;
use Ttc\Intervention\Image\Drivers\Imagick\Color;
use Ttc\Intervention\Image\Drivers\Imagick\Frame;
use Ttc\Intervention\Image\Geometry\Point;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class FillModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(
        protected \Ttc\Intervention\Image\Drivers\Imagick\Color $color,
        protected ?\Ttc\Intervention\Image\Geometry\Point $position = null
    ) {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            if ($this->hasPosition()) {
                $this->floodFillWithColor($frame);
            } else {
                $this->fillAllWithColor($frame);
            }
        }

        return $image;
    }

    protected function floodFillWithColor(\Ttc\Intervention\Image\Drivers\Imagick\Frame $frame): void
    {
        $target = $frame->getCore()->getImagePixelColor(
            $this->position->getX(),
            $this->position->getY()
        );

        $frame->getCore()->floodfillPaintImage(
            $this->color->getPixel(),
            100,
            $target,
            $this->position->getX(),
            $this->position->getY(),
            false,
            Imagick::CHANNEL_ALL
        );
    }

    protected function fillAllWithColor(\Ttc\Intervention\Image\Drivers\Imagick\Frame $frame): void
    {
        $draw = new ImagickDraw();
        $draw->setFillColor($this->color->getPixel());
        $draw->rectangle(
            0,
            0,
            $frame->getCore()->getImageWidth(),
            $frame->getCore()->getImageHeight()
        );
        $frame->getCore()->drawImage($draw);
    }

    protected function hasPosition(): bool
    {
        return !empty($this->position);
    }
}
