<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use ImagickDraw;
use Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier;
use Ttc\Intervention\Image\Drivers\Imagick\Color;
use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class DrawEllipseModifier extends \Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        return $image->eachFrame(function ($frame) {
            $drawing = new ImagickDraw();
            $drawing->setFillColor($this->getBackgroundColor()->getPixel());

            if ($this->ellipse()->hasBorder()) {
                $drawing->setStrokeWidth($this->ellipse()->getBorderSize());
                $drawing->setStrokeColor($this->getBorderColor()->getPixel());
            }

            $drawing->ellipse(
                $this->position->getX(),
                $this->position->getY(),
                $this->ellipse()->getWidth() / 2,
                $this->ellipse()->getHeight() / 2,
                0,
                360
            );

            $frame->getCore()->drawImage($drawing);
        });
    }

    protected function getBackgroundColor(): \Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        $color = parent::getBackgroundColor();
        if (!is_a($color, \Ttc\Intervention\Image\Drivers\Imagick\Color::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode background color.');
        }

        return $color;
    }

    protected function getBorderColor(): \Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        $color = parent::getBorderColor();
        if (!is_a($color, \Ttc\Intervention\Image\Drivers\Imagick\Color::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode border color.');
        }

        return $color;
    }
}
