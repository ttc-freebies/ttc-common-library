<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;
use Ttc\Intervention\Image\Interfaces\SizeInterface;

class ResizeModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(protected ?int $width = null, protected ?int $height = null)
    {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $resizeTo = $this->getAdjustedSize($image);

        foreach ($image as $frame) {
            $frame->getCore()->scaleImage(
                $resizeTo->getWidth(),
                $resizeTo->getHeight()
            );
        }

        return $image;
    }

    protected function getAdjustedSize(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return $image->getSize()->resize($this->width, $this->height);
    }
}
