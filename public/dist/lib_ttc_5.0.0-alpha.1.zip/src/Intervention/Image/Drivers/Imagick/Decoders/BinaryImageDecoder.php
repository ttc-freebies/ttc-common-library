<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Decoders;

use Imagick;
use Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;
use Ttc\Intervention\Image\Drivers\Imagick\Image;
use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class BinaryImageDecoder extends \Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (!is_string($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        if (!$this->inputType($input)->isBinary()) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        $imagick = new Imagick();
        $imagick->readImageBlob($input);
        $imagick = $imagick->coalesceImages();

        $image = new \Ttc\Intervention\Image\Drivers\Imagick\Image($imagick);
        $image->setLoops($imagick->getImageIterations());

        return $image;
    }
}
