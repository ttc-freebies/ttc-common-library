<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Decoders;

use ImagickPixel;
use Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;
use Ttc\Intervention\Image\Drivers\Imagick\Color;
use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Traits\CanValidateColors;

class ArrayColorDecoder extends \Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    use \Ttc\Intervention\Image\Traits\CanValidateColors;

    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (! $this->isValidColorArray($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        if (count($input) === 3) {
            $input[] = 1;
        }

        list($r, $g, $b, $a) = $input;

        $pixel = new ImagickPixel(
            sprintf('rgba(%d, %d, %d, %.2F)', $r, $g, $b, $a)
        );

        return new \Ttc\Intervention\Image\Drivers\Imagick\Color($pixel);
    }
}
