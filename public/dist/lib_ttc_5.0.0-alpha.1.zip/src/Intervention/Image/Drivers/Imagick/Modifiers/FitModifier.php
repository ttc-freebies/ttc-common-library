<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractFitModifier;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class FitModifier extends \Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractFitModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $crop = $this->getCropSize($image);
        $resize = $this->getResizeSize($crop);

        foreach ($image as $frame) {
            $frame->getCore()->extentImage(
                $crop->getWidth(),
                $crop->getHeight(),
                $crop->getPivot()->getX(),
                $crop->getPivot()->getY()
            );

            $frame->getCore()->scaleImage(
                $resize->getWidth(),
                $resize->getHeight()
            );
        }

        return $image;
    }
}
