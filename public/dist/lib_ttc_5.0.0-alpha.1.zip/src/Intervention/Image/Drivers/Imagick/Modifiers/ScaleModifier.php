<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\SizeInterface;

class ScaleModifier extends \Ttc\Intervention\Image\Drivers\Imagick\Modifiers\ResizeModifier
{
    protected function getAdjustedSize(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return $image->getSize()->scale($this->width, $this->height);
    }
}
