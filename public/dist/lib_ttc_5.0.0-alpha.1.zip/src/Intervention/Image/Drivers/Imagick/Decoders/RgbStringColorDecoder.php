<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Decoders;

use ImagickPixel;
use ImagickPixelException;
use Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder;
use Ttc\Intervention\Image\Drivers\Imagick\Color;
use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class RgbStringColorDecoder extends \Ttc\Intervention\Image\Drivers\Abstract\Decoders\AbstractDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (!is_string($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        if (substr($input, 0, 3) !== 'rgb') {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        try {
            $pixel = new ImagickPixel($input);
        } catch (ImagickPixelException $e) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        return new \Ttc\Intervention\Image\Drivers\Imagick\Color($pixel);
    }
}
