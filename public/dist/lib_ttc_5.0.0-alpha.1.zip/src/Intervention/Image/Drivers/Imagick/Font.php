<?php

namespace Ttc\Intervention\Image\Drivers\Imagick;

use Imagick;
use ImagickDraw;
use Ttc\Intervention\Image\Drivers\Abstract\AbstractFont;
use Ttc\Intervention\Image\Exceptions\FontException;
use Ttc\Intervention\Image\Geometry\Polygon;
use Ttc\Intervention\Image\Geometry\Rectangle;
use Ttc\Intervention\Image\Interfaces\ColorInterface;

class Font extends \Ttc\Intervention\Image\Drivers\Abstract\AbstractFont
{
    public function toImagickDraw(): ImagickDraw
    {
        if (!$this->hasFilename()) {
            throw new \Ttc\Intervention\Image\Exceptions\FontException('No font file specified.');
        }

        $draw = new ImagickDraw();
        $draw->setStrokeAntialias(true);
        $draw->setTextAntialias(true);
        $draw->setFont($this->getFilename());
        $draw->setFontSize($this->getSize());
        $draw->setFillColor($this->getColor()->getPixel());
        $draw->setTextAlignment(Imagick::ALIGN_LEFT);

        return $draw;
    }

    public function getColor(): ?\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        $color = parent::getColor();

        if (!is_a($color, \Ttc\Intervention\Image\Drivers\Imagick\Color::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\FontException('Font is not compatible to current driver.');
        }

        return $color;
    }

    /**
     * Calculate box size of current font
     *
     * @return Polygon
     */
    public function getBoxSize(string $text): \Ttc\Intervention\Image\Geometry\Polygon
    {
        // no text - no box size
        if (mb_strlen($text) === 0) {
            return (new \Ttc\Intervention\Image\Geometry\Rectangle(0, 0));
        }

        $draw = $this->toImagickDraw();
        $draw->setStrokeAntialias(true);
        $draw->setTextAntialias(true);
        $dimensions = (new Imagick())->queryFontMetrics($draw, $text);

        return (new \Ttc\Intervention\Image\Geometry\Rectangle(
            intval(round($dimensions['textWidth'])),
            intval(round($dimensions['ascender'] + $dimensions['descender'])),
        ));
    }
}
