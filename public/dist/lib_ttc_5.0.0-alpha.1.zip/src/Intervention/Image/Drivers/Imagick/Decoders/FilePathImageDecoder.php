<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Decoders;

use Exception;
use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class FilePathImageDecoder extends \Ttc\Intervention\Image\Drivers\Imagick\Decoders\BinaryImageDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (! is_string($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        try {
            if (! @is_file($input)) {
                throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
            }
        } catch (Exception $e) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        return parent::decode(file_get_contents($input));
    }
}
