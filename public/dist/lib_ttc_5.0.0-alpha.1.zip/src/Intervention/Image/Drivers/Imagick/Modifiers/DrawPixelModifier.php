<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use ImagickDraw;
use Ttc\Intervention\Image\Geometry\Point;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;
use Ttc\Intervention\Image\Traits\CanHandleInput;

class DrawPixelModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    use \Ttc\Intervention\Image\Traits\CanHandleInput;

    public function __construct(
        protected \Ttc\Intervention\Image\Geometry\Point $position,
        protected $color
    ) {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $color = $this->handleInput($this->color);
        $pixel = new ImagickDraw();
        $pixel->setFillColor($color->getPixel());
        $pixel->point($this->position->getX(), $this->position->getY());

        return $image->eachFrame(function ($frame) use ($pixel) {
            $frame->getCore()->drawImage($pixel);
        });
    }
}
