<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Drivers\Imagick\Frame;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class PixelateModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(protected int $size)
    {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            $this->pixelateFrame($frame);
        }

        return $image;
    }

    protected function pixelateFrame(\Ttc\Intervention\Image\Drivers\Imagick\Frame $frame): void
    {
        $size = $frame->getSize();

        $frame->getCore()->scaleImage(
            max(1, ($size->getWidth() / $this->size)),
            max(1, ($size->getHeight() / $this->size))
        );

        $frame->getCore()->scaleImage($size->getWidth(), $size->getHeight());
    }
}
