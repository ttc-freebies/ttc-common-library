<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Geometry\Rectangle;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\SizeInterface;

class PadDownModifier extends \Ttc\Intervention\Image\Drivers\Imagick\Modifiers\PadModifier
{
    protected function getCropSize(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        $resize = $this->getResizeSize($image);

        return $image->getSize()
            ->contain($resize->width(), $resize->height())
            ->alignPivotTo($resize, $this->position);
    }

    protected function getResizeSize(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\SizeInterface
    {
        return (new \Ttc\Intervention\Image\Geometry\Rectangle($this->width, $this->height))
                ->resizeDown($image->getWidth(), $image->getHeight());
    }
}
