<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use ImagickDraw;
use Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier;
use Ttc\Intervention\Image\Interfaces\DrawableInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class DrawPolygonModifier extends \Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractDrawModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(
        protected \Ttc\Intervention\Image\Interfaces\DrawableInterface $drawable
    ) {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $drawing = new ImagickDraw();
        if ($this->polygon()->hasBackgroundColor()) {
            $drawing->setFillColor($this->getBackgroundColor()->getPixel());
        }

        if ($this->polygon()->hasBorder()) {
            $drawing->setStrokeColor($this->getBorderColor()->getPixel());
            $drawing->setStrokeWidth($this->polygon()->getBorderSize());
        }

        $drawing->polygon($this->points());

        return $image->eachFrame(function ($frame) use ($drawing) {
            $frame->getCore()->drawImage($drawing);
        });
    }

    private function points(): array
    {
        $points = [];
        foreach ($this->polygon() as $point) {
            $points[] = ['x' => $point->getX(), 'y' => $point->getY()];
        }

        return $points;
    }
}
