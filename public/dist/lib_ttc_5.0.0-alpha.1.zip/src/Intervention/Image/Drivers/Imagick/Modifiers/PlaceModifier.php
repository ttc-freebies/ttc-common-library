<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Imagick;
use Ttc\Intervention\Image\Drivers\Imagick\Image;
use Ttc\Intervention\Image\Geometry\Point;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;
use Ttc\Intervention\Image\Interfaces\PointInterface;
use Ttc\Intervention\Image\Traits\CanResolveDriverClass;

class PlaceModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    use \Ttc\Intervention\Image\Traits\CanResolveDriverClass;

    public function __construct(
        protected $element,
        protected string $position,
        protected int $offset_x,
        protected int $offset_y
    ) {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $watermark = $this->decodeWatermark();
        $position = $this->getPosition($image, $watermark);

        foreach ($image as $frame) {
            $frame->getCore()->compositeImage(
                $watermark->getFrame()->getCore(),
                Imagick::COMPOSITE_DEFAULT,
                $position->getX(),
                $position->getY()
            );
        }

        return $image;
    }

    protected function decodeWatermark(): \Ttc\Intervention\Image\Drivers\Imagick\Image
    {
        return $this->resolveDriverClass('InputHandler')->handle($this->element);
    }

    protected function getPosition(\Ttc\Intervention\Image\Interfaces\ImageInterface $image, \Ttc\Intervention\Image\Drivers\Imagick\Image $watermark): \Ttc\Intervention\Image\Interfaces\PointInterface
    {
        $image_size = $image->getSize()->movePivot($this->position, $this->offset_x, $this->offset_y);
        $watermark_size = $watermark->getSize()->movePivot($this->position);

        return $image_size->getRelativePositionTo($watermark_size);
    }
}
