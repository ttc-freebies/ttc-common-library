<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Decoders;

use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Traits\CanDecodeDataUri;

class DataUriImageDecoder extends \Ttc\Intervention\Image\Drivers\Imagick\Decoders\BinaryImageDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    use \Ttc\Intervention\Image\Traits\CanDecodeDataUri;

    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (!is_string($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        $uri = $this->decodeDataUri($input);

        if (! $uri->isValid()) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        if ($uri->isBase64Encoded()) {
            return parent::decode(base64_decode($uri->data()));
        }

        return parent::decode(urldecode($uri->data()));
    }
}
