<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Drivers\Abstract\AbstractTextWriter;
use Ttc\Intervention\Image\Drivers\Imagick\Font;
use Ttc\Intervention\Image\Exceptions\FontException;
use Ttc\Intervention\Image\Interfaces\FontInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class TextWriter extends \Ttc\Intervention\Image\Drivers\Abstract\AbstractTextWriter
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $lines = $this->getAlignedTextBlock();
        foreach ($image as $frame) {
            foreach ($lines as $line) {
                $frame->getCore()->annotateImage(
                    $this->getFont()->toImagickDraw(),
                    $line->getPosition()->getX(),
                    $line->getPosition()->getY(),
                    $this->getFont()->getAngle(),
                    $line
                );
            }

            // debug
            // $lines = new TextBlock($this->text);
            // $box = $lines->getBoundingBox($this->font, $this->position);
            // $points = [];
            // foreach (array_chunk($box->toArray(), 2) as $p) {
            //     $points[] = ['x' => $p[0], 'y' => $p[1]];
            // }
            // $draw = new \ImagickDraw();
            // $draw->setStrokeOpacity(1);
            // $draw->setStrokeColor('black');
            // $draw->setFillColor('transparent');
            // $draw->polygon($points);
            // $frame->getCore()->drawImage($draw);

        }

        return $image;
    }

    protected function getFont(): \Ttc\Intervention\Image\Interfaces\FontInterface
    {
        if (!is_a($this->font, \Ttc\Intervention\Image\Drivers\Imagick\Font::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\FontException('Font is not compatible to current driver.');
        }
        return $this->font;
    }
}
