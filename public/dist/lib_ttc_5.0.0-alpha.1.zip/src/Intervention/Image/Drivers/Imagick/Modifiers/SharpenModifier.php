<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class SharpenModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(protected int $amount)
    {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            $frame->getCore()->unsharpMaskImage(1, 1, $this->amount / 6.25, 0);
        }

        return $image;
    }
}
