<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Decoders;

use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\DecoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Traits\CanValidateBase64;

class Base64ImageDecoder extends \Ttc\Intervention\Image\Drivers\Imagick\Decoders\BinaryImageDecoder implements \Ttc\Intervention\Image\Interfaces\DecoderInterface
{
    use \Ttc\Intervention\Image\Traits\CanValidateBase64;

    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (! $this->isValidBase64($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        return parent::decode(base64_decode($input));
    }
}
