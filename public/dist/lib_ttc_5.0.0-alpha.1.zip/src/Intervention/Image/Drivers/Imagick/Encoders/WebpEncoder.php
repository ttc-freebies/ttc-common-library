<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Encoders;

use Imagick;
use ImagickPixel;
use Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder;
use Ttc\Intervention\Image\EncodedImage;
use Ttc\Intervention\Image\Interfaces\EncoderInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

class WebpEncoder extends \Ttc\Intervention\Image\Drivers\Abstract\Encoders\AbstractEncoder implements \Ttc\Intervention\Image\Interfaces\EncoderInterface
{
    public function __construct(int $quality)
    {
        $this->quality = $quality;
    }

    public function encode(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\EncodedImage
    {
        $format = 'webp';
        $compression = Imagick::COMPRESSION_ZIP;

        $imagick = $image->getFrame()->getCore();
        $imagick->setImageBackgroundColor(new ImagickPixel('transparent'));

        $imagick = $imagick->mergeImageLayers(Imagick::LAYERMETHOD_MERGE);
        $imagick->setFormat($format);
        $imagick->setImageFormat($format);
        $imagick->setCompression($compression);
        $imagick->setImageCompression($compression);
        $imagick->setImageCompressionQuality($this->quality);

        return new \Ttc\Intervention\Image\EncodedImage($imagick->getImagesBlob(), 'image/webp');
    }
}
