<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Decoders;

use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Traits\CanReadHtmlColorNames;

class HtmlColorNameDecoder extends \Ttc\Intervention\Image\Drivers\Imagick\Decoders\HexColorDecoder
{
    use \Ttc\Intervention\Image\Traits\CanReadHtmlColorNames;

    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        if (!is_string($input)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        $hexcolor = $this->hexColorFromColorName($input);

        if (empty($hexcolor)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode input');
        }

        return parent::decode($hexcolor);
    }
}
