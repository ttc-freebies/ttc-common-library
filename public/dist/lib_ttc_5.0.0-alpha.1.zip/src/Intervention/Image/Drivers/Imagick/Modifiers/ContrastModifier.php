<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class ContrastModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(protected int $level)
    {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            $frame->getCore()->sigmoidalContrastImage($this->level > 0, abs($this->level / 4), 0);
        }

        return $image;
    }
}
