<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class GammaModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(protected float $gamma)
    {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            $frame->getCore()->gammaImage($this->gamma);
        }

        return $image;
    }
}
