<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractRotateModifier;
use Ttc\Intervention\Image\Drivers\Imagick\Color;
use Ttc\Intervention\Image\Exceptions\DecoderException;
use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class RotateModifier extends \Ttc\Intervention\Image\Drivers\Abstract\Modifiers\AbstractRotateModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        $background = $this->backgroundColor();
        if (!is_a($background, \Ttc\Intervention\Image\Drivers\Imagick\Color::class)) {
            throw new \Ttc\Intervention\Image\Exceptions\DecoderException('Unable to decode given background color.');
        }

        foreach ($image as $frame) {
            $frame->getCore()->rotateImage(
                $background->getPixel(),
                $this->rotationAngle()
            );
        }

        return $image;
    }

    protected function rotationAngle(): float
    {
        return parent::rotationAngle() * -1;
    }
}
