<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class GreyscaleModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            $frame->getCore()->modulateImage(100, 0, 100);
        }

        return $image;
    }
}
