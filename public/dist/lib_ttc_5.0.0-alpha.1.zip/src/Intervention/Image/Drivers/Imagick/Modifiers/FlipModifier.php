<?php

namespace Ttc\Intervention\Image\Drivers\Imagick\Modifiers;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class FlipModifier implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($image as $frame) {
            $frame->getCore()->flipImage();
        }

        return $image;
    }
}
