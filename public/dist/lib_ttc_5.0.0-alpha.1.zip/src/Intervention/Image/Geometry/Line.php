<?php

namespace Ttc\Intervention\Image\Geometry;

use Ttc\Intervention\Image\Geometry\Traits\HasBackgroundColor;
use Ttc\Intervention\Image\Geometry\Traits\HasBorder;
use Ttc\Intervention\Image\Interfaces\DrawableInterface;

class Line implements \Ttc\Intervention\Image\Interfaces\DrawableInterface
{
    use \Ttc\Intervention\Image\Geometry\Traits\HasBorder;
    use \Ttc\Intervention\Image\Geometry\Traits\HasBackgroundColor;

    public function __construct(
        protected \Ttc\Intervention\Image\Geometry\Point $start,
        protected \Ttc\Intervention\Image\Geometry\Point $end,
        protected int $width = 1
    ) {
        //
    }

    public function getWidth(): int
    {
        return $this->width;
    }

    public function setWidth(int $width): self
    {
        $this->width = $width;

        return $this;
    }

    public function width(int $width): self
    {
        return $this->setWidth($width);
    }

    public function color($color): self
    {
        $this->setBackgroundColor($color);

        return $this;
    }

    public function getStart(): \Ttc\Intervention\Image\Geometry\Point
    {
        return $this->start;
    }

    public function getEnd(): \Ttc\Intervention\Image\Geometry\Point
    {
        return $this->end;
    }

    public function setStart(\Ttc\Intervention\Image\Geometry\Point $start): self
    {
        $this->start = $start;

        return $this;
    }

    public function from(int $x, int $y): self
    {
        $this->getStart()->setX($x);
        $this->getStart()->setY($y);

        return $this;
    }

    public function to(int $x, int $y): self
    {
        $this->getEnd()->setX($x);
        $this->getEnd()->setY($y);

        return $this;
    }

    public function setEnd(\Ttc\Intervention\Image\Geometry\Point $end): self
    {
        $this->end = $end;

        return $this;
    }
}
