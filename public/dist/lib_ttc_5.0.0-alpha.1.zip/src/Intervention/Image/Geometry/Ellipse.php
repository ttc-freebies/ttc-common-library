<?php

namespace Ttc\Intervention\Image\Geometry;

use Ttc\Intervention\Image\Geometry\Traits\HasBackgroundColor;
use Ttc\Intervention\Image\Geometry\Traits\HasBorder;
use Ttc\Intervention\Image\Interfaces\DrawableInterface;

class Ellipse implements \Ttc\Intervention\Image\Interfaces\DrawableInterface
{
    use \Ttc\Intervention\Image\Geometry\Traits\HasBorder;
    use \Ttc\Intervention\Image\Geometry\Traits\HasBackgroundColor;

    public function __construct(
        protected int $width,
        protected int $height,
        protected ?\Ttc\Intervention\Image\Geometry\Point $pivot = null
    ) {
        $this->pivot = $pivot ? $pivot : new \Ttc\Intervention\Image\Geometry\Point();
    }

    public function size(int $width, int $height): self
    {
        return $this->setSize($width, $height);
    }

    public function setSize(int $width, int $height): self
    {
        return $this->setWidth($width)->setHeight($height);
    }

    public function setWidth(int $width): self
    {
        $this->width = $width;

        return $this;
    }

    public function setHeight(int $height): self
    {
        $this->height = $height;

        return $this;
    }

    public function getWidth(): int
    {
        return $this->width;
    }

    public function getHeight(): int
    {
        return $this->height;
    }
}
