<?php

namespace Ttc\Intervention\Image\Geometry;

use Ttc\Intervention\Image\Interfaces\ColorInterface;

class Pixel extends \Ttc\Intervention\Image\Geometry\Point
{
    public function __construct(
        protected \Ttc\Intervention\Image\Interfaces\ColorInterface $background,
        protected int $x,
        protected int $y
    ) {
        //
    }

    public function withBackground(\Ttc\Intervention\Image\Interfaces\ColorInterface $background): self
    {
        $this->background = $background;

        return $this;
    }

    public function background(): \Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        return $this->background;
    }
}
