<?php

namespace Ttc\Intervention\Image\Typography;

use Ttc\Intervention\Image\Interfaces\FontInterface;
use Ttc\Intervention\Image\Geometry\Point;

class Line
{
    protected $position;

    public function __construct(protected string $text)
    {
        $this->position = new \Ttc\Intervention\Image\Geometry\Point();
    }

    public function getPosition(): \Ttc\Intervention\Image\Geometry\Point
    {
        return $this->position;
    }

    public function setPosition(\Ttc\Intervention\Image\Geometry\Point $point): self
    {
        $this->position = $point;

        return $this;
    }

    public function widthInFont(\Ttc\Intervention\Image\Interfaces\FontInterface $font): int
    {
        return $font->getBoxSize($this->text)->getWidth();
    }

    public function __toString(): string
    {
        return $this->text;
    }
}
