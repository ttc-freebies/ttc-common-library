<?php

namespace Ttc\Intervention\Image\Typography;

use Ttc\Intervention\Image\Collection;
use Ttc\Intervention\Image\Geometry\Point;
use Ttc\Intervention\Image\Geometry\Polygon;
use Ttc\Intervention\Image\Geometry\Rectangle;
use Ttc\Intervention\Image\Interfaces\FontInterface;

class TextBlock extends \Ttc\Intervention\Image\Collection
{
    public function __construct(string $text)
    {
        foreach (explode("\n", $text) as $line) {
            $this->push(new \Ttc\Intervention\Image\Typography\Line($line));
        }
    }

    public function getBoundingBox(\Ttc\Intervention\Image\Interfaces\FontInterface $font, \Ttc\Intervention\Image\Geometry\Point $pivot = null): \Ttc\Intervention\Image\Geometry\Polygon
    {
        $pivot = $pivot ? $pivot : new \Ttc\Intervention\Image\Geometry\Point();

        // bounding box
        $box = (new \Ttc\Intervention\Image\Geometry\Rectangle(
            $this->longestLine()->widthInFont($font),
            $font->leadingInPixels() * ($this->count() - 1) + $font->capHeight()
        ));

        // set pivot
        $box->setPivot($pivot);

        // align
        $box->align($font->getAlign());
        $box->valign($font->getValign());

        $box->rotate($font->getAngle());

        return $box;
    }

    /**
     * Return array of lines in text block
     *
     * @return array
     */
    public function lines(): array
    {
        return $this->items;
    }

    public function getLine($key): ?\Ttc\Intervention\Image\Typography\Line
    {
        if (!array_key_exists($key, $this->lines())) {
            return null;
        }

        return $this->lines()[$key];
    }

    /**
     * Return line with most characters of text block
     *
     * @return Line
     */
    public function longestLine(): \Ttc\Intervention\Image\Typography\Line
    {
        $lines = $this->lines();
        usort($lines, function ($a, $b) {
            if (mb_strlen($a) === mb_strlen($b)) {
                return 0;
            }
            return (mb_strlen($a) > mb_strlen($b)) ? -1 : 1;
        });

        return $lines[0];
    }
}
