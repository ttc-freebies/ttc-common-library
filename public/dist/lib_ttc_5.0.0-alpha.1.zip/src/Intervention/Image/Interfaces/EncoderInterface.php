<?php

namespace Ttc\Intervention\Image\Interfaces;

use Ttc\Intervention\Image\EncodedImage;

interface EncoderInterface
{
    public function encode(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\EncodedImage;
}
