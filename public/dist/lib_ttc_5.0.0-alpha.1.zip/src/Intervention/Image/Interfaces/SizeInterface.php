<?php

namespace Ttc\Intervention\Image\Interfaces;

interface SizeInterface
{
    public function getWidth(): int;
    public function getHeight(): int;
    public function getPivot(): \Ttc\Intervention\Image\Interfaces\PointInterface;
    public function setWidth(int $width): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function setHeight(int $height): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function setPivot(\Ttc\Intervention\Image\Interfaces\PointInterface $pivot): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function getAspectRatio(): float;
    public function fitsInto(\Ttc\Intervention\Image\Interfaces\SizeInterface $size): bool;
    public function isLandscape(): bool;
    public function isPortrait(): bool;
    public function movePivot(string $position, int $offset_x = 0, int $offset_y = 0): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function alignPivotTo(\Ttc\Intervention\Image\Interfaces\SizeInterface $size, string $position): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function getRelativePositionTo(\Ttc\Intervention\Image\Interfaces\SizeInterface $size): \Ttc\Intervention\Image\Interfaces\PointInterface;
    public function resize(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function resizeDown(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function scale(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function scaleDown(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function cover(int $width, int $height): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function contain(int $width, int $height): \Ttc\Intervention\Image\Interfaces\SizeInterface;
}
