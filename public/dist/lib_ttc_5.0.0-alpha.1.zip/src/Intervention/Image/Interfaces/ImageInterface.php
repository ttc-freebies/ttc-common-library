<?php

namespace Ttc\Intervention\Image\Interfaces;

use Countable;
use Ttc\Intervention\Image\EncodedImage;
use Traversable;

interface ImageInterface extends Traversable, Countable
{
    public function getFrame(int $key = 0): ?\Ttc\Intervention\Image\Interfaces\FrameInterface;
    public function addFrame(\Ttc\Intervention\Image\Interfaces\FrameInterface $frame): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function setLoops(int $count): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function getLoops(): int;
    public function getSize(): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function isAnimated(): bool;
    public function modify(\Ttc\Intervention\Image\Interfaces\ModifierInterface $modifier): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function encode(\Ttc\Intervention\Image\Interfaces\EncoderInterface $encoder): \Ttc\Intervention\Image\EncodedImage;
    public function toJpeg(int $quality = 75): \Ttc\Intervention\Image\EncodedImage;
    public function toWebp(int $quality = 75): \Ttc\Intervention\Image\EncodedImage;
    public function toGif(): \Ttc\Intervention\Image\EncodedImage;
    public function toPng(): \Ttc\Intervention\Image\EncodedImage;
    public function pickColors(int $x, int $y): \Ttc\Intervention\Image\Interfaces\CollectionInterface;
    public function text(string $text, int $x, int $y, ?callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function pickColor(int $x, int $y, int $frame_key = 0): ?\Ttc\Intervention\Image\Interfaces\ColorInterface;
    public function greyscale(): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function blur(int $amount = 5): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function rotate(float $angle, $background = 'ffffff'): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function place($element, string $position = 'top-left', int $offset_x = 0, int $offset_y = 0): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function fill($color, ?int $x = null, ?int $y = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function pixelate(int $size): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function resize(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function resizeDown(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function scale(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function scaleDown(?int $width = null, ?int $height = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function fit(int $width, int $height, string $position = 'center'): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function fitDown(int $width, int $height, string $position = 'center'): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function pad(int $width, int $height, $background = 'ffffff', string $position = 'center'): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function padDown(int $width, int $height, $background = 'ffffff', string $position = 'center'): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function drawPixel(int $x, int $y, $color = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function drawRectangle(int $x, int $y, ?callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function drawEllipse(int $x, int $y, ?callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function drawLine(callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function drawPolygon(callable $init = null): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function sharpen(int $amount = 10): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function flip(): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function flop(): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function getWidth(): int;
    public function getHeight(): int;
    public function destroy(): void;
}
