<?php

namespace Ttc\Intervention\Image\Interfaces;

interface DecoderInterface
{
    public function decode($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface;
}
