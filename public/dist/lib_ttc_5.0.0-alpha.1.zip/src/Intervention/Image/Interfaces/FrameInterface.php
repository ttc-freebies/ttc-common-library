<?php

namespace Ttc\Intervention\Image\Interfaces;

interface FrameInterface
{
    public function toImage(): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function getCore();
    public function setCore($core): \Ttc\Intervention\Image\Interfaces\FrameInterface;
    public function getSize(): \Ttc\Intervention\Image\Interfaces\SizeInterface;
    public function getDelay(): float;
    public function setDelay(float $delay): \Ttc\Intervention\Image\Interfaces\FrameInterface;
    public function getDispose(): int;
    public function setDispose(int $dispose): \Ttc\Intervention\Image\Interfaces\FrameInterface;
    public function setOffset(int $left, int $top): \Ttc\Intervention\Image\Interfaces\FrameInterface;
    public function getOffsetLeft(): int;
    public function setOffsetLeft(int $offset): \Ttc\Intervention\Image\Interfaces\FrameInterface;
    public function getOffsetTop(): int;
    public function setOffsetTop(int $offset): \Ttc\Intervention\Image\Interfaces\FrameInterface;
}
