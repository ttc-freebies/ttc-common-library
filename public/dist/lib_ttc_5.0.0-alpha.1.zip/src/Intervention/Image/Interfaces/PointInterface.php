<?php

namespace Ttc\Intervention\Image\Interfaces;

interface PointInterface
{
    public function getX(): int;
    public function getY(): int;
}
