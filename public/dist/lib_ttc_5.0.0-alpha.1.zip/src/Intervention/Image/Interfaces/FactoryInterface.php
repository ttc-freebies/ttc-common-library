<?php

namespace Ttc\Intervention\Image\Interfaces;

interface FactoryInterface
{
    public function newImage(int $width, int $height): \Ttc\Intervention\Image\Interfaces\ImageInterface;
    public function newCore(int $width, int $height);
}
