<?php

namespace Ttc\Intervention\Image\Interfaces;

interface ModifierInterface
{
    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface;
}
