<?php

namespace Ttc\Intervention\Image;

use Ttc\Intervention\Image\Interfaces\ImageInterface;
use Ttc\Intervention\Image\Interfaces\ModifierInterface;

class ModifierStack implements \Ttc\Intervention\Image\Interfaces\ModifierInterface
{
    public function __construct(protected array $modifiers)
    {
        //
    }

    public function apply(\Ttc\Intervention\Image\Interfaces\ImageInterface $image): \Ttc\Intervention\Image\Interfaces\ImageInterface
    {
        foreach ($this->modifiers as $modifier) {
            $modifier->apply($image);
        }

        return $image;
    }

    public function push(\Ttc\Intervention\Image\Interfaces\ModifierInterface $modifier): self
    {
        $this->modifiers[] = $modifier;

        return $this;
    }
}
