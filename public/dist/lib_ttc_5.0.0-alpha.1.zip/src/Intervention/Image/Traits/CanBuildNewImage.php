<?php

namespace Ttc\Intervention\Image\Traits;

use Ttc\Intervention\Image\Interfaces\FactoryInterface;

trait CanBuildNewImage
{
    use \Ttc\Intervention\Image\Traits\CanResolveDriverClass;

    public function imageFactory(): \Ttc\Intervention\Image\Interfaces\FactoryInterface
    {
        return $this->resolveDriverClass('ImageFactory');
    }
}
