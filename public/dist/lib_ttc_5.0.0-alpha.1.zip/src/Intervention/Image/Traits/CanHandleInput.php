<?php

namespace Ttc\Intervention\Image\Traits;

use Ttc\Intervention\Image\Interfaces\ColorInterface;
use Ttc\Intervention\Image\Interfaces\ImageInterface;

trait CanHandleInput
{
    use \Ttc\Intervention\Image\Traits\CanResolveDriverClass;

    public function handleInput($input): \Ttc\Intervention\Image\Interfaces\ImageInterface|\Ttc\Intervention\Image\Interfaces\ColorInterface
    {
        return $this->resolveDriverClass('InputHandler')->handle($input);
    }
}
