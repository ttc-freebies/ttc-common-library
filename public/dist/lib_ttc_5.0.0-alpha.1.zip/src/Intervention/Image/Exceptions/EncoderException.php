<?php

namespace Ttc\Intervention\Image\Exceptions;

class EncoderException extends \RuntimeException
{
    //
}
