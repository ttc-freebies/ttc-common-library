<?php

namespace Ttc\Intervention\Image\Exceptions;

class NotWritableException extends \RuntimeException
{
    # nothing to override
}
