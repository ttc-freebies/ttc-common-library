<?php

namespace Ttc\Intervention\Image\Exceptions;

class DecoderException extends \RuntimeException
{
    //
}
