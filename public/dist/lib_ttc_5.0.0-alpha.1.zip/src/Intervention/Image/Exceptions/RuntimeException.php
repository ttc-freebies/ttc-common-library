<?php

namespace Ttc\Intervention\Image\Exceptions;

class RuntimeException extends \RuntimeException
{
    //
}
