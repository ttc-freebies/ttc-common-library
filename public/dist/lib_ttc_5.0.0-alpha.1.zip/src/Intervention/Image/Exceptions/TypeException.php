<?php

namespace Ttc\Intervention\Image\Exceptions;

class TypeException extends \RuntimeException
{
    //
}
