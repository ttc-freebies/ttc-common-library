<?php

namespace Ttc\Intervention\Image\Exceptions;

class GeometryException extends \RuntimeException
{
    //
}
