<?php

namespace Ttc\Intervention\Image\Exceptions;

class MissingDriverComponentException extends \RuntimeException
{
    //
}
