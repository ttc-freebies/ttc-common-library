<?php

namespace Ttc\Intervention\Image\Exceptions;

class FontException extends \RuntimeException
{
    //
}
