<?php

namespace Ttc\Freebies\Intervention\Image\Exception;

class RuntimeException extends \Ttc\Freebies\Intervention\Image\Exception\ImageException
{
    # nothing to override
}
