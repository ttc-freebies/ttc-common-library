<?php

namespace Ttc\Freebies\Intervention\Image\Exception;

class NotSupportedException extends \Ttc\Freebies\Intervention\Image\Exception\ImageException
{
    # nothing to override
}
