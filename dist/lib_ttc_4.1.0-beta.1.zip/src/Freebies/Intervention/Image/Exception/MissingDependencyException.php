<?php

namespace Ttc\Freebies\Intervention\Image\Exception;

class MissingDependencyException extends \Ttc\Freebies\Intervention\Image\Exception\ImageException
{
    # nothing to override
}
