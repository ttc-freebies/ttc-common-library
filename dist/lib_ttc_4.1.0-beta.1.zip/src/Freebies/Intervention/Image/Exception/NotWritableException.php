<?php

namespace Ttc\Freebies\Intervention\Image\Exception;

class NotWritableException extends \Ttc\Freebies\Intervention\Image\Exception\ImageException
{
    # nothing to override
}
