<?php

namespace Ttc\Freebies\Intervention\Image\Exception;

class InvalidArgumentException extends \Ttc\Freebies\Intervention\Image\Exception\ImageException
{
    # nothing to override
}
