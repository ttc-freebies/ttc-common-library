<?php

namespace Ttc\Freebies\Intervention\Image\Exception;

class NotReadableException extends \Ttc\Freebies\Intervention\Image\Exception\ImageException
{
    # nothing to override
}
